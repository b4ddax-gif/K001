package com.example.data.repository

import com.example.data.local.K001Dao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.*

class StudyRepository(private val dao: K001Dao) {

  val userProfile: Flow<UserProfile?> = dao.getUserProfileFlow()
  val allSubjects: Flow<List<Subject>> = dao.getAllSubjectsFlow()
  val allChapters: Flow<List<Chapter>> = dao.getAllChaptersFlow()
  val allNotes: Flow<List<Note>> = dao.getAllNotesFlow()
  val allTasks: Flow<List<StudyTask>> = dao.getAllTasksFlow()
  val allSessions: Flow<List<StudySession>> = dao.getAllSessionsFlow()
  val latestSession: Flow<StudySession?> = dao.getLatestSessionFlow()
  val allRevisions: Flow<List<RevisionItem>> = dao.getAllRevisionsFlow()
  val allTests: Flow<List<TestItem>> = dao.getAllTestsFlow()
  val allFlashcards: Flow<List<Flashcard>> = dao.getAllFlashcardsFlow()
  val allExams: Flow<List<ExamItem>> = dao.getAllExamsFlow()

  fun getChaptersForSubject(subjectId: Long): Flow<List<Chapter>> =
    dao.getChaptersForSubjectFlow(subjectId)

  fun getNotesForChapter(chapterId: Long): Flow<List<Note>> =
    dao.getNotesForChapterFlow(chapterId)

  // Profile operations
  suspend fun getUserProfile(): UserProfile? = dao.getUserProfile()

  suspend fun saveProfile(profile: UserProfile) {
    dao.insertOrUpdateProfile(profile)
  }

  suspend fun updateDailyGoal(goalMinutes: Int) {
    val current = dao.getUserProfile() ?: UserProfile()
    dao.insertOrUpdateProfile(current.copy(dailyGoalMinutes = goalMinutes))
  }

  suspend fun updateNotificationSetting(enabled: Boolean) {
    val current = dao.getUserProfile() ?: UserProfile()
    dao.insertOrUpdateProfile(current.copy(notificationsEnabled = enabled))
  }

  suspend fun updateSoundSetting(enabled: Boolean) {
    val current = dao.getUserProfile() ?: UserProfile()
    dao.insertOrUpdateProfile(current.copy(soundEnabled = enabled))
  }

  // Subjects & Chapters
  suspend fun addSubject(name: String, colorHex: String = "#38BDF8"): Long {
    return dao.insertSubject(Subject(name = name, colorHex = colorHex))
  }

  suspend fun updateSubject(subject: Subject) {
    dao.updateSubject(subject)
  }

  suspend fun deleteSubject(subjectId: Long) {
    dao.deleteChaptersBySubjectId(subjectId)
    dao.deleteSubject(subjectId)
  }

  suspend fun addChapter(subjectId: Long, name: String, priority: String = "MEDIUM"): Long {
    return dao.insertChapter(Chapter(subjectId = subjectId, name = name, priority = priority))
  }

  suspend fun updateChapter(chapter: Chapter) {
    dao.updateChapter(chapter)
  }

  suspend fun deleteChapter(chapterId: Long) {
    dao.deleteChapter(chapterId)
  }

  // Notes
  suspend fun saveNote(note: Note): Long {
    return if (note.id == 0L) {
      dao.insertNote(note)
    } else {
      dao.updateNote(note.copy(updatedAt = System.currentTimeMillis()))
      note.id
    }
  }

  suspend fun deleteNote(noteId: Long) {
    dao.deleteNote(noteId)
  }

  suspend fun togglePinNote(note: Note) {
    dao.updateNote(note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis()))
  }

  suspend fun toggleFavoriteNote(note: Note) {
    dao.updateNote(note.copy(isFavorite = !note.isFavorite, updatedAt = System.currentTimeMillis()))
  }

  // Tasks
  suspend fun addTask(title: String, subjectName: String = ""): Long {
    return dao.insertTask(StudyTask(title = title, subjectName = subjectName))
  }

  suspend fun toggleTask(task: StudyTask) {
    dao.updateTask(task.copy(isCompleted = !task.isCompleted))
  }

  suspend fun updateTask(task: StudyTask) {
    dao.updateTask(task)
  }

  suspend fun deleteTask(taskId: Long) {
    dao.deleteTask(taskId)
  }

  // Study Sessions & Streak calculation
  suspend fun recordStudySession(
    subjectId: Long,
    subjectName: String,
    chapterId: Long,
    chapterName: String,
    durationMinutes: Int
  ): UserProfile {
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    dao.insertSession(
      StudySession(
        subjectId = subjectId,
        subjectName = subjectName,
        chapterId = chapterId,
        chapterName = chapterName,
        durationMinutes = durationMinutes,
        timestamp = System.currentTimeMillis(),
        dateString = today
      )
    )

    // Update chapter study minutes if applicable
    if (chapterId > 0) {
      val chapter = dao.getChapterById(chapterId)
      if (chapter != null) {
        val newStatus = if (chapter.status == "NOT_STARTED") "IN_PROGRESS" else chapter.status
        dao.updateChapter(
          chapter.copy(
            totalStudyMinutes = chapter.totalStudyMinutes + durationMinutes,
            status = newStatus
          )
        )
      }
    }

    // Streak calculation
    val currentProfile = dao.getUserProfile() ?: UserProfile()
    val lastDate = currentProfile.lastStudyDate

    var newStreak = currentProfile.currentStreak
    if (lastDate.isEmpty()) {
      newStreak = 1
    } else if (lastDate == today) {
      // Already studied today, streak stays the same
    } else {
      // Check if last study was yesterday
      val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
      try {
        val lastTime = sdf.parse(lastDate)?.time ?: 0L
        val diffDays = (System.currentTimeMillis() - lastTime) / (1000 * 60 * 60 * 24)
        newStreak = if (diffDays <= 1) {
          currentProfile.currentStreak + 1
        } else {
          1
        }
      } catch (e: Exception) {
        newStreak = 1
      }
    }

    val newLongest = maxOf(newStreak, currentProfile.longestStreak)
    val updatedProfile = currentProfile.copy(
      currentStreak = newStreak,
      longestStreak = newLongest,
      lastStudyDate = today
    )
    dao.insertOrUpdateProfile(updatedProfile)
    return updatedProfile
  }

  // Revisions
  suspend fun scheduleRevision(
    chapterId: Long,
    chapterName: String,
    subjectName: String,
    daysAhead: Int
  ): Long {
    val scheduledTime = System.currentTimeMillis() + (daysAhead.toLong() * 24 * 60 * 60 * 1000)
    return dao.insertRevision(
      RevisionItem(
        chapterId = chapterId,
        chapterName = chapterName,
        subjectName = subjectName,
        scheduledDate = scheduledTime,
        intervalDays = daysAhead
      )
    )
  }

  suspend fun completeRevision(item: RevisionItem, rating: String) {
    dao.updateRevision(
      item.copy(
        isCompleted = true,
        lastRating = rating,
        completedDate = System.currentTimeMillis()
      )
    )
    // Recommend next spaced revision based on difficulty
    val nextDays = when (rating) {
      "EASY" -> 14
      "OKAY" -> 5
      else -> 2 // DIFFICULT
    }
    scheduleRevision(item.chapterId, item.chapterName, item.subjectName, nextDays)
  }

  suspend fun deleteRevision(id: Long) = dao.deleteRevision(id)

  // Tests
  suspend fun saveTestResult(test: TestItem): Long {
    return dao.insertTest(test)
  }

  suspend fun deleteTest(id: Long) = dao.deleteTest(id)

  // Flashcards
  suspend fun addFlashcard(card: Flashcard): Long = dao.insertFlashcard(card)
  suspend fun updateFlashcard(card: Flashcard) = dao.updateFlashcard(card)
  suspend fun deleteFlashcard(id: Long) = dao.deleteFlashcard(id)

  // Exams
  suspend fun addExam(name: String, dateMillis: Long, subjects: String): Long {
    return dao.insertExam(ExamItem(name = name, examDateMillis = dateMillis, subjects = subjects))
  }

  suspend fun deleteExam(id: Long) = dao.deleteExam(id)

  // Global Search
  suspend fun searchAll(query: String): SearchResults {
    val trimmed = query.trim()
    if (trimmed.isEmpty()) return SearchResults()
    return SearchResults(
      subjects = dao.searchSubjects(trimmed),
      chapters = dao.searchChapters(trimmed),
      notes = dao.searchNotes(trimmed),
      tests = dao.searchTests(trimmed)
    )
  }

  // Reset progress
  suspend fun resetAllData() {
    dao.clearSubjects()
    dao.clearChapters()
    dao.clearNotes()
    dao.clearTasks()
    dao.clearSessions()
    dao.clearRevisions()
    dao.clearTests()
    dao.clearFlashcards()
    dao.clearExams()
    val current = dao.getUserProfile() ?: UserProfile()
    dao.insertOrUpdateProfile(current.copy(isOnboarded = false, currentStreak = 0, longestStreak = 0, lastStudyDate = ""))
  }

  // Seed sample starter curriculum if completely empty
  suspend fun seedSampleCurriculumIfNeeded() {
    val profile = dao.getUserProfile()
    if (profile == null) {
      dao.insertOrUpdateProfile(
        UserProfile(
          studentName = "Alex",
          dailyGoalMinutes = 120,
          preferredDurationMinutes = 25,
          isOnboarded = false
        )
      )
    }
  }
}

data class SearchResults(
  val subjects: List<Subject> = emptyList(),
  val chapters: List<Chapter> = emptyList(),
  val notes: List<Note> = emptyList(),
  val tests: List<TestItem> = emptyList()
)
