package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface K001Dao {
  // User Profile
  @Query("SELECT * FROM user_profile WHERE id = 1")
  fun getUserProfileFlow(): Flow<UserProfile?>

  @Query("SELECT * FROM user_profile WHERE id = 1")
  suspend fun getUserProfile(): UserProfile?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateProfile(profile: UserProfile)

  // Subjects
  @Query("SELECT * FROM subjects ORDER BY name ASC")
  fun getAllSubjectsFlow(): Flow<List<Subject>>

  @Query("SELECT * FROM subjects WHERE id = :id")
  suspend fun getSubjectById(id: Long): Subject?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSubject(subject: Subject): Long

  @Update
  suspend fun updateSubject(subject: Subject)

  @Query("DELETE FROM subjects WHERE id = :id")
  suspend fun deleteSubject(id: Long)

  // Chapters
  @Query("SELECT * FROM chapters WHERE subjectId = :subjectId ORDER BY orderIndex ASC, id ASC")
  fun getChaptersForSubjectFlow(subjectId: Long): Flow<List<Chapter>>

  @Query("SELECT * FROM chapters ORDER BY id DESC")
  fun getAllChaptersFlow(): Flow<List<Chapter>>

  @Query("SELECT * FROM chapters WHERE id = :id")
  suspend fun getChapterById(id: Long): Chapter?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertChapter(chapter: Chapter): Long

  @Update
  suspend fun updateChapter(chapter: Chapter)

  @Query("DELETE FROM chapters WHERE id = :id")
  suspend fun deleteChapter(id: Long)

  @Query("DELETE FROM chapters WHERE subjectId = :subjectId")
  suspend fun deleteChaptersBySubjectId(subjectId: Long)

  // Notes
  @Query("SELECT * FROM notes ORDER BY isPinned DESC, updatedAt DESC")
  fun getAllNotesFlow(): Flow<List<Note>>

  @Query("SELECT * FROM notes WHERE id = :id")
  suspend fun getNoteById(id: Long): Note?

  @Query("SELECT * FROM notes WHERE chapterId = :chapterId ORDER BY updatedAt DESC")
  fun getNotesForChapterFlow(chapterId: Long): Flow<List<Note>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNote(note: Note): Long

  @Update
  suspend fun updateNote(note: Note)

  @Query("DELETE FROM notes WHERE id = :id")
  suspend fun deleteNote(id: Long)

  // Tasks
  @Query("SELECT * FROM tasks ORDER BY isCompleted ASC, id DESC")
  fun getAllTasksFlow(): Flow<List<StudyTask>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTask(task: StudyTask): Long

  @Update
  suspend fun updateTask(task: StudyTask)

  @Query("DELETE FROM tasks WHERE id = :id")
  suspend fun deleteTask(id: Long)

  // Study Sessions
  @Query("SELECT * FROM study_sessions ORDER BY timestamp DESC")
  fun getAllSessionsFlow(): Flow<List<StudySession>>

  @Query("SELECT * FROM study_sessions WHERE dateString = :dateString")
  fun getSessionsForDateFlow(dateString: String): Flow<List<StudySession>>

  @Query("SELECT * FROM study_sessions ORDER BY timestamp DESC LIMIT 1")
  fun getLatestSessionFlow(): Flow<StudySession?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSession(session: StudySession): Long

  // Revisions
  @Query("SELECT * FROM revisions ORDER BY scheduledDate ASC")
  fun getAllRevisionsFlow(): Flow<List<RevisionItem>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRevision(item: RevisionItem): Long

  @Update
  suspend fun updateRevision(item: RevisionItem)

  @Query("DELETE FROM revisions WHERE id = :id")
  suspend fun deleteRevision(id: Long)

  // Tests
  @Query("SELECT * FROM tests ORDER BY timestamp DESC")
  fun getAllTestsFlow(): Flow<List<TestItem>>

  @Query("SELECT * FROM tests WHERE id = :id")
  suspend fun getTestById(id: Long): TestItem?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTest(test: TestItem): Long

  @Query("DELETE FROM tests WHERE id = :id")
  suspend fun deleteTest(id: Long)

  // Flashcards
  @Query("SELECT * FROM flashcards ORDER BY id DESC")
  fun getAllFlashcardsFlow(): Flow<List<Flashcard>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertFlashcard(flashcard: Flashcard): Long

  @Update
  suspend fun updateFlashcard(flashcard: Flashcard)

  @Query("DELETE FROM flashcards WHERE id = :id")
  suspend fun deleteFlashcard(id: Long)

  // Exams
  @Query("SELECT * FROM exams ORDER BY examDateMillis ASC")
  fun getAllExamsFlow(): Flow<List<ExamItem>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertExam(exam: ExamItem): Long

  @Query("DELETE FROM exams WHERE id = :id")
  suspend fun deleteExam(id: Long)

  // Global Search Queries
  @Query("SELECT * FROM subjects WHERE name LIKE '%' || :query || '%'")
  suspend fun searchSubjects(query: String): List<Subject>

  @Query("SELECT * FROM chapters WHERE name LIKE '%' || :query || '%'")
  suspend fun searchChapters(query: String): List<Chapter>

  @Query("SELECT * FROM notes WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%'")
  suspend fun searchNotes(query: String): List<Note>

  @Query("SELECT * FROM tests WHERE title LIKE '%' || :query || '%' OR subjectName LIKE '%' || :query || '%'")
  suspend fun searchTests(query: String): List<TestItem>

  // Reset entire database
  @Query("DELETE FROM subjects")
  suspend fun clearSubjects()
  @Query("DELETE FROM chapters")
  suspend fun clearChapters()
  @Query("DELETE FROM notes")
  suspend fun clearNotes()
  @Query("DELETE FROM tasks")
  suspend fun clearTasks()
  @Query("DELETE FROM study_sessions")
  suspend fun clearSessions()
  @Query("DELETE FROM revisions")
  suspend fun clearRevisions()
  @Query("DELETE FROM tests")
  suspend fun clearTests()
  @Query("DELETE FROM flashcards")
  suspend fun clearFlashcards()
  @Query("DELETE FROM exams")
  suspend fun clearExams()
}
