package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
  @PrimaryKey val id: Int = 1,
  val studentName: String = "",
  val dailyGoalMinutes: Int = 120,
  val preferredDurationMinutes: Int = 25,
  val currentStreak: Int = 0,
  val longestStreak: Int = 0,
  val lastStudyDate: String = "",
  val isOnboarded: Boolean = false,
  val notificationsEnabled: Boolean = true,
  val soundEnabled: Boolean = true
)

@Entity(tableName = "subjects")
data class Subject(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val colorHex: String = "#38BDF8",
  val iconName: String = "menu_book",
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chapters")
data class Chapter(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val subjectId: Long,
  val name: String,
  val status: String = "NOT_STARTED", // NOT_STARTED, IN_PROGRESS, COMPLETED
  val priority: String = "MEDIUM", // LOW, MEDIUM, HIGH
  val totalStudyMinutes: Int = 0,
  val orderIndex: Int = 0
)

@Entity(tableName = "notes")
data class Note(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val content: String,
  val subjectId: Long = 0,
  val subjectName: String = "",
  val chapterId: Long = 0,
  val chapterName: String = "",
  val isPinned: Boolean = false,
  val isFavorite: Boolean = false,
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasks")
data class StudyTask(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val isCompleted: Boolean = false,
  val subjectName: String = "",
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "study_sessions")
data class StudySession(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val subjectId: Long = 0,
  val subjectName: String = "",
  val chapterId: Long = 0,
  val chapterName: String = "",
  val durationMinutes: Int = 0,
  val timestamp: Long = System.currentTimeMillis(),
  val dateString: String = ""
)

@Entity(tableName = "revisions")
data class RevisionItem(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val chapterId: Long = 0,
  val chapterName: String,
  val subjectName: String,
  val scheduledDate: Long,
  val intervalDays: Int = 1,
  val isCompleted: Boolean = false,
  val lastRating: String? = null, // EASY, OKAY, DIFFICULT
  val completedDate: Long? = null
)

@Entity(tableName = "tests")
data class TestItem(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val subjectName: String,
  val chapterName: String,
  val totalQuestions: Int,
  val score: Int,
  val percentage: Int,
  val correctCount: Int,
  val wrongCount: Int,
  val skippedCount: Int,
  val timeTakenSeconds: Int,
  val timestamp: Long = System.currentTimeMillis(),
  val questionsJson: String = "[]",
  val userAnswersJson: String = "[]"
)

@Entity(tableName = "flashcards")
data class Flashcard(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val subjectName: String,
  val chapterName: String = "",
  val frontText: String,
  val backText: String,
  val difficulty: String = "MEDIUM", // EASY, MEDIUM, HARD
  val reviewCount: Int = 0,
  val lastReviewedAt: Long = 0
)

@Entity(tableName = "exams")
data class ExamItem(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val examDateMillis: Long,
  val subjects: String
)
