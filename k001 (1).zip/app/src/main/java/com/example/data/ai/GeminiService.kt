package com.example.data.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatMessage(
  val text: String,
  val isUser: Boolean,
  val timestamp: Long = System.currentTimeMillis()
)

data class GeneratedMcq(
  val question: String,
  val options: List<String>,
  val correctOptionIndex: Int,
  val explanation: String
)

data class GeneratedCard(
  val front: String,
  val back: String
)

enum class NoteFormat(val label: String, val promptInstruction: String) {
  SUMMARIZE("Summarize", "Create a concise, executive summary of this study material with key takeaways."),
  SHORT_NOTES("Short Notes", "Create clear, high-yield bulleted short study notes suitable for quick review."),
  DETAILED_NOTES("Detailed Notes", "Create comprehensive, structured academic notes with deep explanations, bullet points, and definitions."),
  IMPORTANT_POINTS("Important Points", "Extract all critical concepts, formulas, rules, and facts into prioritized key points."),
  EXAM_REVISION("Exam Revision", "Format this material as an intensive exam-prep cheat sheet with high-probability questions and memory hooks."),
  FLASHCARDS("Flashcards", "Extract key concept-definition pairs from this material in JSON format.")
}

object GeminiService {
  private const val MODEL = "gemini-3.5-flash"
  private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

  private val client = OkHttpClient.Builder()
    .connectTimeout(60, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(60, TimeUnit.SECONDS)
    .build()

  fun isApiKeyAvailable(): Boolean {
    val key = BuildConfig.GEMINI_API_KEY
    return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
  }

  suspend fun askAssistant(prompt: String, conversationHistory: List<ChatMessage> = emptyList()): Result<String> {
    if (!isApiKeyAvailable()) {
      return Result.failure(
        IllegalStateException("Gemini API key is not configured. Please add your GEMINI_API_KEY in the Secrets panel in AI Studio.")
      )
    }

    return withContext(Dispatchers.IO) {
      try {
        val root = JSONObject()
        val contentsArray = JSONArray()

        // System context
        val systemContent = JSONObject()
        systemContent.put("role", "user")
        val sysParts = JSONArray()
        sysParts.put(JSONObject().put("text", "You are the K001 AI Academic Study Assistant. You provide precise, insightful, and pedagogical explanations for students. Format equations and structured bullet points cleanly."))
        systemContent.put("parts", sysParts)
        contentsArray.put(systemContent)

        val sysAck = JSONObject()
        sysAck.put("role", "model")
        val sysAckParts = JSONArray()
        sysAckParts.put(JSONObject().put("text", "Understood. I am ready to help you study smarter and stay consistent."))
        sysAck.put("parts", sysAckParts)
        contentsArray.put(sysAck)

        // Include recent history (up to last 6 turns)
        val recentHistory = conversationHistory.takeLast(6)
        for (msg in recentHistory) {
          val histObj = JSONObject()
          histObj.put("role", if (msg.isUser) "user" else "model")
          val pArray = JSONArray()
          pArray.put(JSONObject().put("text", msg.text))
          histObj.put("parts", pArray)
          contentsArray.put(histObj)
        }

        // Current user message
        val currentObj = JSONObject()
        currentObj.put("role", "user")
        val pArray = JSONArray()
        pArray.put(JSONObject().put("text", prompt))
        currentObj.put("parts", pArray)
        contentsArray.put(currentObj)

        root.put("contents", contentsArray)

        val url = "$BASE_URL?key=${BuildConfig.GEMINI_API_KEY}"
        val requestBody = root.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
          .url(url)
          .post(requestBody)
          .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: ""

        if (!response.isSuccessful) {
          return@withContext Result.failure(
            Exception("API Error (${response.code}): ${parseErrorMessage(responseBody)}")
          )
        }

        val json = JSONObject(responseBody)
        val text = extractResponseText(json)
        Result.success(text)
      } catch (e: Exception) {
        Result.failure(e)
      }
    }
  }

  suspend fun generateNotes(content: String, format: NoteFormat): Result<String> {
    if (!isApiKeyAvailable()) {
      return Result.failure(
        IllegalStateException("Gemini API key is not configured. Please add your GEMINI_API_KEY in the Secrets panel in AI Studio.")
      )
    }

    val prompt = """
      Task: ${format.promptInstruction}
      
      Study Material:
      $content
      
      Please provide well-formatted, clean markdown output with clear section headers, bullet points, and key definitions.
    """.trimIndent()

    return askAssistant(prompt)
  }

  suspend fun generateMCQs(
    subject: String,
    chapter: String,
    count: Int,
    difficulty: String
  ): Result<List<GeneratedMcq>> {
    if (!isApiKeyAvailable()) {
      return Result.failure(
        IllegalStateException("Gemini API key is not configured. Please add your GEMINI_API_KEY in the Secrets panel in AI Studio.")
      )
    }

    val prompt = """
      Generate exactly $count multiple-choice questions for the following topic:
      Subject: $subject
      Chapter/Topic: $chapter
      Difficulty level: $difficulty
      
      You MUST respond with a valid JSON array only, without code markdown backticks or commentary.
      Each object in the array must follow this schema:
      [
        {
          "question": "Question text here",
          "options": ["Option A", "Option B", "Option C", "Option D"],
          "correctOptionIndex": 0,
          "explanation": "Clear explanation of why this option is correct."
        }
      ]
    """.trimIndent()

    return withContext(Dispatchers.IO) {
      try {
        val result = askAssistant(prompt)
        if (result.isFailure) {
          return@withContext Result.failure(result.exceptionOrNull()!!)
        }

        val rawText = result.getOrNull() ?: ""
        // Clean possible markdown code fences
        val cleanJson = rawText
          .replace("```json", "")
          .replace("```", "")
          .trim()

        val jsonArray = JSONArray(cleanJson)
        val list = mutableListOf<GeneratedMcq>()
        for (i in 0 until jsonArray.length()) {
          val obj = jsonArray.getJSONObject(i)
          val q = obj.getString("question")
          val optsArray = obj.getJSONArray("options")
          val opts = mutableListOf<String>()
          for (j in 0 until optsArray.length()) {
            opts.add(optsArray.getString(j))
          }
          val correct = obj.getInt("correctOptionIndex")
          val exp = obj.optString("explanation", "Correct answer verified.")
          list.add(GeneratedMcq(q, opts, correct, exp))
        }

        if (list.isEmpty()) {
          Result.failure(Exception("No questions could be parsed from AI response."))
        } else {
          Result.success(list)
        }
      } catch (e: Exception) {
        Result.failure(Exception("Failed to parse AI quiz: ${e.message}"))
      }
    }
  }

  suspend fun generateFlashcards(material: String): Result<List<GeneratedCard>> {
    if (!isApiKeyAvailable()) {
      return Result.failure(
        IllegalStateException("Gemini API key is not configured. Please add your GEMINI_API_KEY in the Secrets panel in AI Studio.")
      )
    }

    val prompt = """
      Extract key concepts and facts from this study material into flashcards.
      Study Material:
      $material
      
      You MUST return a valid JSON array only, without markdown fences or additional text:
      [
        {
          "front": "Concept or Question",
          "back": "Clear definition or answer"
        }
      ]
    """.trimIndent()

    return withContext(Dispatchers.IO) {
      try {
        val result = askAssistant(prompt)
        if (result.isFailure) {
          return@withContext Result.failure(result.exceptionOrNull()!!)
        }

        val rawText = result.getOrNull() ?: ""
        val cleanJson = rawText.replace("```json", "").replace("```", "").trim()
        val jsonArray = JSONArray(cleanJson)
        val list = mutableListOf<GeneratedCard>()
        for (i in 0 until jsonArray.length()) {
          val obj = jsonArray.getJSONObject(i)
          val front = obj.getString("front")
          val back = obj.getString("back")
          list.add(GeneratedCard(front, back))
        }
        Result.success(list)
      } catch (e: Exception) {
        Result.failure(Exception("Failed to parse flashcards: ${e.message}"))
      }
    }
  }

  private fun extractResponseText(json: JSONObject): String {
    val candidates = json.optJSONArray("candidates") ?: return "No response generated."
    if (candidates.length() == 0) return "No response generated."
    val first = candidates.getJSONObject(0)
    val content = first.optJSONObject("content") ?: return "Empty content."
    val parts = content.optJSONArray("parts") ?: return "Empty parts."
    if (parts.length() == 0) return "Empty parts."
    val sb = StringBuilder()
    for (i in 0 until parts.length()) {
      val p = parts.getJSONObject(i)
      sb.append(p.optString("text", ""))
    }
    return sb.toString().trim()
  }

  private fun parseErrorMessage(body: String): String {
    return try {
      val json = JSONObject(body)
      val err = json.optJSONObject("error")
      err?.optString("message") ?: body
    } catch (e: Exception) {
      body
    }
  }
}
