package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.*

@Database(
  entities = [
    UserProfile::class,
    Subject::class,
    Chapter::class,
    Note::class,
    StudyTask::class,
    StudySession::class,
    RevisionItem::class,
    TestItem::class,
    Flashcard::class,
    ExamItem::class
  ],
  version = 1,
  exportSchema = false
)
abstract class K001Database : RoomDatabase() {
  abstract fun k001Dao(): K001Dao

  companion object {
    @Volatile
    private var INSTANCE: K001Database? = null

    fun getDatabase(context: Context): K001Database {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          K001Database::class.java,
          "k001_study_database"
        )
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
