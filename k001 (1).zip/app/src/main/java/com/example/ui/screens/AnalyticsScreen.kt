package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.K001Card
import com.example.ui.components.StreakBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsScreen(
  viewModel: K001ViewModel,
  onBack: () -> Unit
) {
  val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
  val allSessions by viewModel.allSessions.collectAsStateWithLifecycle()
  val allSubjects by viewModel.allSubjects.collectAsStateWithLifecycle()
  val allTests by viewModel.allTests.collectAsStateWithLifecycle()

  val totalMinutes = remember(allSessions) { allSessions.sumOf { it.durationMinutes } }
  val totalHours = String.format(Locale.US, "%.1f", totalMinutes / 60f)

  val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
  val todayMinutes = remember(allSessions, todayStr) {
    allSessions.filter { it.dateString == todayStr }.sumOf { it.durationMinutes }
  }

  // 7 days computation
  val last7DaysData = remember(allSessions) {
    val list = mutableListOf<DayStudyStat>()
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val dayNameSdf = SimpleDateFormat("EEE", Locale.getDefault())
    val cal = Calendar.getInstance()

    for (i in 6 downTo 0) {
      val c = Calendar.getInstance()
      c.add(Calendar.DAY_OF_YEAR, -i)
      val dateStr = sdf.format(c.time)
      val dayName = dayNameSdf.format(c.time)
      val mins = allSessions.filter { it.dateString == dateStr }.sumOf { it.durationMinutes }
      list.add(DayStudyStat(dayName, mins))
    }
    list
  }

  val maxDayMinutes = (last7DaysData.maxOfOrNull { it.minutes } ?: 60).coerceAtLeast(60)

  // Subject distribution
  val subjectDistribution = remember(allSessions, allSubjects) {
    allSubjects.map { sub ->
      val mins = allSessions.filter { it.subjectId == sub.id || it.subjectName == sub.name }.sumOf { it.durationMinutes }
      sub.name to mins
    }
  }

  // Test statistics
  val averageScore = if (allTests.isNotEmpty()) (allTests.map { it.percentage }.average()).toInt() else 0
  val passedTests = allTests.count { it.percentage >= 60 }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text("Analytics & Progress", fontWeight = FontWeight.Bold, color = TextPrimary)
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
      )
    },
    containerColor = DarkBg
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 12.dp),
      contentPadding = PaddingValues(top = 10.dp, bottom = 48.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      // Key Metrics Row
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          StatTile(
            title = "Total Time",
            value = "${totalHours} hrs",
            subtitle = "$totalMinutes mins recorded",
            accentColor = AccentBlue,
            modifier = Modifier.weight(1f)
          )
          StatTile(
            title = "Today",
            value = "$todayMinutes min",
            subtitle = "Goal: ${userProfile?.dailyGoalMinutes ?: 120} min",
            accentColor = AccentEmerald,
            modifier = Modifier.weight(1f)
          )
        }
      }

      // Streaks Card
      item {
        K001Card(
          backgroundColor = DarkSurface,
          borderColor = DarkBorder
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(44.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .background(Color(0xFF2E1C0C)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Filled.LocalFireDepartment, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(24.dp))
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = "Consistency Engine",
                  style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                  )
                )
                Text(
                  text = "Current: ${userProfile?.currentStreak ?: 0} days • Best: ${userProfile?.longestStreak ?: 0} days",
                  style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
              }
            }

            StreakBadge(streakDays = userProfile?.currentStreak ?: 0)
          }
        }
      }

      // 7-Day Consistency Bar Chart
      item {
        K001Card(
          backgroundColor = DarkSurface,
          borderColor = DarkBorder
        ) {
          Text(
            text = "LAST 7 DAYS ACTIVITY",
            style = MaterialTheme.typography.labelSmall.copy(
              color = AccentBlue,
              letterSpacing = 1.sp,
              fontWeight = FontWeight.Bold
            )
          )
          Spacer(modifier = Modifier.height(16.dp))

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .height(130.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
          ) {
            last7DaysData.forEach { dayStat ->
              val heightFraction = (dayStat.minutes.toFloat() / maxDayMinutes).coerceIn(0.08f, 1f)

              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier.weight(1f)
              ) {
                Text(
                  text = "${dayStat.minutes}m",
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.sp,
                    color = if (dayStat.minutes > 0) AccentBlue else TextMuted
                  )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                  modifier = Modifier
                    .fillMaxHeight(heightFraction)
                    .width(18.dp)
                    .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                    .background(if (dayStat.minutes > 0) AccentBlue else ProgressTrack)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = dayStat.dayLabel,
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 11.sp,
                    color = TextSecondary
                  )
                )
              }
            }
          }
        }
      }

      // Subject-wise distribution
      item {
        K001Card(
          backgroundColor = DarkSurface,
          borderColor = DarkBorder
        ) {
          Text(
            text = "SUBJECT BREAKDOWN",
            style = MaterialTheme.typography.labelSmall.copy(
              color = AccentEmerald,
              letterSpacing = 1.sp,
              fontWeight = FontWeight.Bold
            )
          )
          Spacer(modifier = Modifier.height(12.dp))

          if (subjectDistribution.isEmpty() || totalMinutes == 0) {
            Text(
              text = "Start tracking study sessions to view distribution across subjects.",
              style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
            )
          } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
              subjectDistribution.forEach { (subName, mins) ->
                val fraction = if (totalMinutes > 0) (mins.toFloat() / totalMinutes) else 0f
                val pct = (fraction * 100).toInt()

                Column {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(text = subName, style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontWeight = FontWeight.Medium))
                    Text(text = "${mins}m ($pct%)", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                  LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier
                      .fillMaxWidth()
                      .height(6.dp)
                      .clip(RoundedCornerShape(3.dp)),
                    color = AccentBlue,
                    trackColor = ProgressTrack
                  )
                }
              }
            }
          }
        }
      }

      // Test Performance Summary
      item {
        K001Card(
          backgroundColor = DarkSurfaceElevated,
          borderColor = DarkBorder
        ) {
          Text(
            text = "ASSESSMENT PERFORMANCE",
            style = MaterialTheme.typography.labelSmall.copy(
              color = AccentAmber,
              letterSpacing = 1.sp,
              fontWeight = FontWeight.Bold
            )
          )
          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = "${allTests.size}",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
              )
              Text("Tests Taken", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = "$passedTests",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = AccentEmerald)
              )
              Text("Passed", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = "$averageScore%",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = AccentAmber)
              )
              Text("Avg Score", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
            }
          }
        }
      }
    }
  }
}

data class DayStudyStat(
  val dayLabel: String,
  val minutes: Int
)

@Composable
fun StatTile(
  title: String,
  value: String,
  subtitle: String,
  accentColor: Color,
  modifier: Modifier = Modifier
) {
  K001Card(
    modifier = modifier,
    backgroundColor = DarkSurface,
    borderColor = DarkBorder
  ) {
    Text(
      text = title.uppercase(),
      style = MaterialTheme.typography.labelSmall.copy(
        color = accentColor,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp
      )
    )
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = value,
      style = MaterialTheme.typography.headlineSmall.copy(
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )
    )
    Text(
      text = subtitle,
      style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
      modifier = Modifier.padding(top = 2.dp)
    )
  }
}
