package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun K001Card(
  modifier: Modifier = Modifier,
  onClick: (() -> Unit)? = null,
  backgroundColor: Color = DarkSurface,
  borderColor: Color = DarkBorder,
  contentPadding: Dp = 12.dp,
  content: @Composable ColumnScope.() -> Unit
) {
  val shape = RoundedCornerShape(10.dp)
  Card(
    modifier = modifier
      .clip(shape)
      .border(1.dp, borderColor, shape)
      .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
    shape = shape,
    colors = CardDefaults.cardColors(containerColor = backgroundColor),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
  ) {
    Column(
      modifier = Modifier.padding(contentPadding),
      content = content
    )
  }
}

@Composable
fun CircularProgressDisplay(
  progress: Float,
  currentValueText: String,
  goalValueText: String,
  percentageText: String,
  modifier: Modifier = Modifier,
  size: Dp = 110.dp,
  strokeWidth: Dp = 8.dp,
  primaryColor: Color = AccentBlue,
  trackColor: Color = ProgressTrack
) {
  val animatedProgress by animateFloatAsState(
    targetValue = progress.coerceIn(0f, 1f),
    animationSpec = tween(durationMillis = 800),
    label = "progress"
  )

  Box(
    modifier = modifier.size(size),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val strokePx = strokeWidth.toPx()
      drawCircle(
        color = trackColor,
        style = Stroke(width = strokePx)
      )
      drawArc(
        color = primaryColor,
        startAngle = -90f,
        sweepAngle = animatedProgress * 360f,
        useCenter = false,
        style = Stroke(width = strokePx, cap = StrokeCap.Round)
      )
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = percentageText,
        style = MaterialTheme.typography.titleLarge.copy(
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
      )
      Text(
        text = "$currentValueText / $goalValueText",
        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
        modifier = Modifier.padding(top = 1.dp)
      )
    }
  }
}

@Composable
fun StreakBadge(
  streakDays: Int,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .clip(RoundedCornerShape(6.dp))
      .background(Color(0xFF261E14))
      .border(1.dp, AccentAmber.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
      .padding(horizontal = 8.dp, vertical = 3.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      imageVector = Icons.Filled.LocalFireDepartment,
      contentDescription = "Streak",
      tint = AccentAmber,
      modifier = Modifier.size(14.dp)
    )
    Spacer(modifier = Modifier.width(3.dp))
    Text(
      text = "$streakDays day streak",
      style = MaterialTheme.typography.labelSmall.copy(
        fontWeight = FontWeight.Bold,
        color = AccentAmber
      )
    )
  }
}

@Composable
fun StatusBadge(status: String) {
  val (bgColor, textColor, label) = when (status) {
    "COMPLETED" -> Triple(AccentEmerald.copy(alpha = 0.15f), AccentEmerald, "COMPLETED")
    "IN_PROGRESS" -> Triple(AccentBlue.copy(alpha = 0.15f), AccentBlue, "IN PROGRESS")
    else -> Triple(DarkBorderLight.copy(alpha = 0.3f), TextSecondary, "NOT STARTED")
  }

  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(4.dp))
      .background(bgColor)
      .border(0.5.dp, textColor.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
      .padding(horizontal = 6.dp, vertical = 2.dp)
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall.copy(
        fontWeight = FontWeight.SemiBold,
        fontSize = 9.sp,
        color = textColor
      )
    )
  }
}

@Composable
fun PriorityBadge(priority: String) {
  val (bgColor, textColor) = when (priority) {
    "HIGH" -> Pair(AccentRose.copy(alpha = 0.15f), AccentRose)
    "MEDIUM" -> Pair(AccentAmber.copy(alpha = 0.15f), AccentAmber)
    else -> Pair(AccentEmerald.copy(alpha = 0.15f), AccentEmerald)
  }

  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(4.dp))
      .background(bgColor)
      .border(0.5.dp, textColor.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
      .padding(horizontal = 6.dp, vertical = 2.dp)
  ) {
    Text(
      text = priority,
      style = MaterialTheme.typography.labelSmall.copy(
        fontWeight = FontWeight.SemiBold,
        fontSize = 9.sp,
        color = textColor
      )
    )
  }
}

@Composable
fun EmptyStateView(
  title: String,
  subtitle: String,
  icon: ImageVector,
  actionButtonText: String? = null,
  onActionClick: (() -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(32.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(64.dp)
        .clip(CircleShape)
        .background(DarkSurfaceVariant)
        .border(1.dp, DarkBorder, CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = TextSecondary,
        modifier = Modifier.size(32.dp)
      )
    }
    Spacer(modifier = Modifier.height(16.dp))
    Text(
      text = title,
      style = MaterialTheme.typography.titleMedium.copy(
        fontWeight = FontWeight.SemiBold,
        color = TextPrimary
      ),
      textAlign = TextAlign.Center
    )
    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = subtitle,
      style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
      textAlign = TextAlign.Center
    )
    if (actionButtonText != null && onActionClick != null) {
      Spacer(modifier = Modifier.height(20.dp))
      Button(
        onClick = onActionClick,
        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.testTag("empty_state_action_button")
      ) {
        Text(
          text = actionButtonText,
          style = MaterialTheme.typography.labelLarge.copy(color = Color.Black)
        )
      }
    }
  }
}

@Composable
fun K001ConfirmDialog(
  title: String,
  message: String,
  confirmButtonText: String = "Confirm",
  dismissButtonText: String = "Cancel",
  isDestructive: Boolean = false,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = DarkSurfaceElevated,
    titleContentColor = TextPrimary,
    textContentColor = TextSecondary,
    title = {
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
      )
    },
    text = {
      Text(
        text = message,
        style = MaterialTheme.typography.bodyMedium
      )
    },
    confirmButton = {
      Button(
        onClick = onConfirm,
        colors = ButtonDefaults.buttonColors(
          containerColor = if (isDestructive) AccentRose else AccentBlue
        ),
        shape = RoundedCornerShape(10.dp)
      ) {
        Text(
          text = confirmButtonText,
          style = MaterialTheme.typography.labelMedium.copy(
            color = if (isDestructive) Color.White else Color.Black,
            fontWeight = FontWeight.Bold
          )
        )
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text(
          text = dismissButtonText,
          style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary)
        )
      }
    }
  )
}
