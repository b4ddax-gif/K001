package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel

@Composable
fun OnboardingScreen(
  viewModel: K001ViewModel,
  onComplete: () -> Unit
) {
  var name by remember { mutableStateOf("") }
  var dailyGoal by remember { mutableStateOf("120") }
  var selectedDuration by remember { mutableIntStateOf(25) }

  val durations = listOf(25, 50, 90)

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(DarkBg)
      .statusBarsPadding()
      .navigationBarsPadding()
      .verticalScroll(rememberScrollState())
      .padding(24.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Spacer(modifier = Modifier.height(24.dp))

    // App Logo & Brand
    Box(
      modifier = Modifier
        .size(80.dp)
        .clip(CircleShape)
        .background(DarkSurfaceElevated)
        .border(1.dp, AccentBlue.copy(alpha = 0.5f), CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Image(
        painter = painterResource(id = R.drawable.k001_icon),
        contentDescription = "K001 Logo",
        modifier = Modifier
          .size(54.dp)
          .clip(CircleShape)
      )
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = "K001",
      style = MaterialTheme.typography.displayLarge.copy(
        fontWeight = FontWeight.Black,
        letterSpacing = 2.sp,
        color = TextPrimary
      )
    )

    Text(
      text = "Study Smarter. Stay Consistent.",
      style = MaterialTheme.typography.titleMedium.copy(
        color = AccentBlue,
        fontWeight = FontWeight.Medium
      ),
      modifier = Modifier.padding(top = 4.dp)
    )

    Text(
      text = "Your intelligent, dark-first academic command center.",
      style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
      textAlign = TextAlign.Center,
      modifier = Modifier.padding(top = 8.dp, bottom = 32.dp)
    )

    // Form
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = DarkSurface),
      border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkBorder))
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Text(
          text = "Personalize Your Routine",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Student Name
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Student Name (Optional)") },
          placeholder = { Text("e.g. Alex", color = TextMuted) },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AccentBlue,
            unfocusedBorderColor = DarkBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedLabelColor = AccentBlue,
            unfocusedLabelColor = TextSecondary,
            focusedContainerColor = DarkSurfaceVariant,
            unfocusedContainerColor = DarkSurfaceVariant
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("onboarding_name_input")
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Daily Goal (Minutes)
        OutlinedTextField(
          value = dailyGoal,
          onValueChange = { if (it.all { char -> char.isDigit() }) dailyGoal = it },
          label = { Text("Daily Study Goal (Minutes)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AccentBlue,
            unfocusedBorderColor = DarkBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedLabelColor = AccentBlue,
            unfocusedLabelColor = TextSecondary,
            focusedContainerColor = DarkSurfaceVariant,
            unfocusedContainerColor = DarkSurfaceVariant
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("onboarding_goal_input")
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Preferred Session Duration
        Text(
          text = "Preferred Study Session Duration",
          style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          durations.forEach { duration ->
            val isSelected = selectedDuration == duration
            FilterChip(
              selected = isSelected,
              onClick = { selectedDuration = duration },
              label = {
                Text(
                  text = "$duration min",
                  style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) Color.Black else TextPrimary
                  )
                )
              },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = AccentBlue,
                containerColor = DarkSurfaceElevated
              ),
              border = FilterChipDefaults.filterChipBorder(
                borderColor = if (isSelected) AccentBlue else DarkBorder,
                selectedBorderColor = AccentBlue,
                enabled = true,
                selected = isSelected
              ),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f)
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Primary CTA Button
    Button(
      onClick = {
        val goalNum = dailyGoal.toIntOrNull() ?: 120
        viewModel.completeOnboarding(
          name = name.trim(),
          dailyGoal = goalNum,
          sessionDuration = selectedDuration
        )
        onComplete()
      },
      colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier
        .fillMaxWidth()
        .height(52.dp)
        .testTag("onboarding_start_button")
    ) {
      Text(
        text = "Start Studying",
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          color = Color(0xFF04121E)
        )
      )
      Spacer(modifier = Modifier.width(8.dp))
      Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
        contentDescription = null,
        tint = Color(0xFF04121E),
        modifier = Modifier.size(20.dp)
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    TextButton(
      onClick = {
        viewModel.completeOnboarding(
          name = "Student",
          dailyGoal = 120,
          sessionDuration = 25
        )
        onComplete()
      },
      modifier = Modifier.testTag("onboarding_skip_button")
    ) {
      Text(
        text = "Skip for now",
        style = MaterialTheme.typography.labelLarge.copy(color = TextSecondary)
      )
    }

    Spacer(modifier = Modifier.height(24.dp))
  }
}
