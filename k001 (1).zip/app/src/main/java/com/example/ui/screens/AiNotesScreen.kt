package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ai.NoteFormat
import com.example.ui.components.K001Card
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiNotesScreen(
  viewModel: K001ViewModel,
  onBack: () -> Unit
) {
  val context = LocalContext.current
  val isGenerating by viewModel.isGeneratingNotes.collectAsStateWithLifecycle()
  val resultNote by viewModel.aiNotesResult.collectAsStateWithLifecycle()
  val errorNote by viewModel.notesError.collectAsStateWithLifecycle()

  var inputText by remember { mutableStateOf("") }
  var selectedFormat by remember { mutableStateOf(NoteFormat.SHORT_NOTES) }
  var saveNoteTitle by remember { mutableStateOf("") }
  var showSaveSuccess by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text("AI Notes Generator", fontWeight = FontWeight.Bold, color = TextPrimary)
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
      )
    },
    containerColor = DarkBg
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Text(
        text = "Paste text or bullet points, and AI will transform it into structured academic study notes.",
        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
      )

      // Material Input Box
      OutlinedTextField(
        value = inputText,
        onValueChange = { inputText = it },
        label = { Text("Study Material / Raw Content") },
        placeholder = { Text("Paste textbook excerpts, lecture transcripts, or topic definitions...", color = TextMuted) },
        minLines = 5,
        maxLines = 10,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = AccentViolet,
          unfocusedBorderColor = DarkBorder,
          focusedTextColor = TextPrimary,
          unfocusedTextColor = TextPrimary,
          focusedContainerColor = DarkSurface,
          unfocusedContainerColor = DarkSurface
        ),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("ai_notes_input")
      )

      // Format Selector
      Text(
        text = "Select Output Format",
        style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary, fontWeight = FontWeight.SemiBold)
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf(
          NoteFormat.SHORT_NOTES,
          NoteFormat.SUMMARIZE,
          NoteFormat.DETAILED_NOTES
        ).forEach { format ->
          val isSelected = selectedFormat == format
          FilterChip(
            selected = isSelected,
            onClick = { selectedFormat = format },
            label = { Text(format.label, fontSize = 12.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = AccentViolet,
              containerColor = DarkSurfaceElevated
            ),
            border = FilterChipDefaults.filterChipBorder(
              borderColor = if (isSelected) AccentViolet else DarkBorder,
              selectedBorderColor = AccentViolet,
              enabled = true,
              selected = isSelected
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f)
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf(
          NoteFormat.IMPORTANT_POINTS,
          NoteFormat.EXAM_REVISION
        ).forEach { format ->
          val isSelected = selectedFormat == format
          FilterChip(
            selected = isSelected,
            onClick = { selectedFormat = format },
            label = { Text(format.label, fontSize = 12.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = AccentViolet,
              containerColor = DarkSurfaceElevated
            ),
            border = FilterChipDefaults.filterChipBorder(
              borderColor = if (isSelected) AccentViolet else DarkBorder,
              selectedBorderColor = AccentViolet,
              enabled = true,
              selected = isSelected
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f)
          )
        }
      }

      // Generate Button
      Button(
        onClick = {
          if (inputText.isNotBlank() && !isGenerating) {
            viewModel.generateAiNotes(inputText.trim(), selectedFormat)
            saveNoteTitle = "${selectedFormat.label} Note"
            showSaveSuccess = false
          }
        },
        enabled = inputText.isNotBlank() && !isGenerating,
        colors = ButtonDefaults.buttonColors(containerColor = AccentViolet),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("generate_notes_button")
      ) {
        if (isGenerating) {
          CircularProgressIndicator(
            modifier = Modifier.size(20.dp),
            color = Color.White,
            strokeWidth = 2.dp
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text("Generating High-Yield Notes...", color = Color.White)
        } else {
          Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color.White)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Generate Structured Notes", fontWeight = FontWeight.Bold, color = Color.White)
        }
      }

      // Error Display
      errorNote?.let { err ->
        K001Card(
          backgroundColor = AccentRose.copy(alpha = 0.1f),
          borderColor = AccentRose.copy(alpha = 0.4f)
        ) {
          Text(text = err, color = AccentRose, style = MaterialTheme.typography.bodyMedium)
        }
      }

      // Result Display
      resultNote?.let { generated ->
        K001Card(
          backgroundColor = DarkSurface,
          borderColor = AccentViolet.copy(alpha = 0.4f)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "GENERATED RESULT",
              style = MaterialTheme.typography.labelSmall.copy(
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Bold,
                color = AccentViolet
              )
            )

            Row {
              IconButton(
                onClick = {
                  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                  clipboard.setPrimaryClip(ClipData.newPlainText("AI Note", generated))
                  Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                }
              ) {
                Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy", tint = TextSecondary)
              }

              IconButton(
                onClick = {
                  val title = if (saveNoteTitle.isNotBlank()) saveNoteTitle else "AI Generated Note"
                  viewModel.saveNote(title = title, content = generated)
                  showSaveSuccess = true
                  Toast.makeText(context, "Saved into your Notes!", Toast.LENGTH_SHORT).show()
                }
              ) {
                Icon(
                  imageVector = if (showSaveSuccess) Icons.Filled.Check else Icons.Outlined.Save,
                  contentDescription = "Save to Notes",
                  tint = if (showSaveSuccess) AccentEmerald else AccentBlue
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = generated,
            style = MaterialTheme.typography.bodyMedium.copy(
              color = TextPrimary,
              lineHeight = 22.sp
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(40.dp))
    }
  }
}
