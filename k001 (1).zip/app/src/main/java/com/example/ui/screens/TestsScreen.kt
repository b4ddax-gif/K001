package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ai.GeneratedMcq
import com.example.ui.components.EmptyStateView
import com.example.ui.components.K001Card
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestsScreen(
  viewModel: K001ViewModel,
  onBack: () -> Unit,
  onOpenTest: () -> Unit,
  onViewResult: (Long) -> Unit
) {
  val allTests by viewModel.allTests.collectAsStateWithLifecycle()
  val allSubjects by viewModel.allSubjects.collectAsStateWithLifecycle()
  val allChapters by viewModel.allChapters.collectAsStateWithLifecycle()

  var showCreateTestModal by remember { mutableStateOf(false) }
  var selectedSubjectName by remember { mutableStateOf("") }
  var selectedChapterName by remember { mutableStateOf("") }
  var selectedCount by remember { mutableIntStateOf(5) }
  var selectedDifficulty by remember { mutableStateOf("MEDIUM") }

  val isGeneratingQuiz by viewModel.isGeneratingQuiz.collectAsStateWithLifecycle()
  val quizError by viewModel.quizError.collectAsStateWithLifecycle()

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text("Tests & Quizzes", fontWeight = FontWeight.Bold, color = TextPrimary)
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
      )
    },
    floatingActionButton = {
      FloatingActionButton(
        onClick = {
          selectedSubjectName = allSubjects.firstOrNull()?.name ?: "General"
          selectedChapterName = allChapters.firstOrNull()?.name ?: "All Topics"
          showCreateTestModal = true
        },
        containerColor = AccentAmber,
        contentColor = Color.Black,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.testTag("create_test_fab")
      ) {
        Icon(Icons.Filled.Add, contentDescription = "Create Test")
      }
    },
    containerColor = DarkBg
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 12.dp)
    ) {
      if (allTests.isEmpty()) {
        EmptyStateView(
          title = "No test records yet",
          subtitle = "Generate an AI practice test or take a quick assessment to evaluate your knowledge.",
          icon = Icons.Filled.Quiz,
          actionButtonText = "Take a Test",
          onActionClick = {
            selectedSubjectName = allSubjects.firstOrNull()?.name ?: "General"
            selectedChapterName = allChapters.firstOrNull()?.name ?: "All Topics"
            showCreateTestModal = true
          },
          modifier = Modifier.weight(1f)
        )
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(top = 10.dp, bottom = 96.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          items(allTests, key = { it.id }) { test ->
            val dateStr = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault()).format(Date(test.timestamp))
            val isPassed = test.percentage >= 60

            K001Card(
              backgroundColor = DarkSurface,
              borderColor = if (isPassed) AccentEmerald.copy(alpha = 0.3f) else AccentRose.copy(alpha = 0.3f),
              onClick = { onViewResult(test.id) }
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = test.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                      fontWeight = FontWeight.Bold,
                      color = TextPrimary
                    )
                  )
                  Text(
                    text = "${test.subjectName} • ${test.chapterName}",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
                    modifier = Modifier.padding(top = 2.dp)
                  )
                  Text(
                    text = "$dateStr • ${test.timeTakenSeconds}s",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted),
                    modifier = Modifier.padding(top = 4.dp)
                  )
                }

                Column(horizontalAlignment = Alignment.End) {
                  Text(
                    text = "${test.percentage}%",
                    style = MaterialTheme.typography.headlineSmall.copy(
                      fontWeight = FontWeight.Black,
                      color = if (isPassed) AccentEmerald else AccentRose
                    )
                  )
                  Text(
                    text = "${test.correctCount}/${test.totalQuestions} correct",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                  )
                }
              }
            }
          }
        }
      }
    }
  }

  // Create Test Dialog
  if (showCreateTestModal) {
    AlertDialog(
      onDismissRequest = { if (!isGeneratingQuiz) showCreateTestModal = false },
      containerColor = DarkSurfaceElevated,
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = AccentAmber)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Generate AI Test", color = TextPrimary, fontWeight = FontWeight.Bold)
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          // Subject Selection
          OutlinedTextField(
            value = selectedSubjectName,
            onValueChange = { selectedSubjectName = it },
            label = { Text("Subject") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentAmber,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          // Chapter / Topic Selection
          OutlinedTextField(
            value = selectedChapterName,
            onValueChange = { selectedChapterName = it },
            label = { Text("Topic / Chapter") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentAmber,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          // Questions Count
          Text("Questions Count", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(5, 10, 15).forEach { count ->
              FilterChip(
                selected = selectedCount == count,
                onClick = { selectedCount = count },
                label = { Text("$count Qs") },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = AccentAmber,
                  containerColor = DarkSurfaceVariant
                )
              )
            }
          }

          // Difficulty
          Text("Difficulty", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("EASY", "MEDIUM", "HARD").forEach { diff ->
              FilterChip(
                selected = selectedDifficulty == diff,
                onClick = { selectedDifficulty = diff },
                label = { Text(diff, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = AccentAmber,
                  containerColor = DarkSurfaceVariant
                )
              )
            }
          }

          if (isGeneratingQuiz) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center
            ) {
              CircularProgressIndicator(modifier = Modifier.size(24.dp), color = AccentAmber)
              Spacer(modifier = Modifier.width(10.dp))
              Text("Creating questions with AI...", color = AccentAmber, fontSize = 13.sp)
            }
          }

          quizError?.let { err ->
            Text(text = err, color = AccentRose, fontSize = 12.sp)
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (selectedSubjectName.isNotBlank() && !isGeneratingQuiz) {
              val topic = selectedChapterName.ifBlank { "General Concepts" }
              viewModel.startAiTest(
                subject = selectedSubjectName.trim(),
                chapter = topic.trim(),
                count = selectedCount,
                difficulty = selectedDifficulty
              ) {
                showCreateTestModal = false
                onOpenTest()
              }
            }
          },
          enabled = !isGeneratingQuiz,
          colors = ButtonDefaults.buttonColors(containerColor = AccentAmber)
        ) {
          Text("Start Test", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showCreateTestModal = false }, enabled = !isGeneratingQuiz) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }
}
