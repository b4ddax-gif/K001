package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val K001ColorScheme = darkColorScheme(
  primary = AccentBlue,
  onPrimary = Color(0xFF04121E),
  primaryContainer = Color(0xFF0C243C),
  onPrimaryContainer = AccentBlueLight,
  secondary = AccentPrimaryLight,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFF1E1B4B),
  onSecondaryContainer = Color(0xFFC7D2FE),
  tertiary = AccentEmerald,
  onTertiary = Color(0xFF022C19),
  tertiaryContainer = Color(0xFF064E3B),
  onTertiaryContainer = Color(0xFFA7F3D0),
  background = DarkBg,
  onBackground = TextPrimary,
  surface = DarkSurface,
  onSurface = TextPrimary,
  surfaceVariant = DarkSurfaceVariant,
  onSurfaceVariant = TextSecondary,
  outline = DarkBorder,
  outlineVariant = DarkBorderLight,
  error = AccentRose,
  onError = Color.White,
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // K001 is dark-first by design
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = K001ColorScheme,
    typography = Typography,
    content = content
  )
}
