package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.EmptyStateView
import com.example.ui.components.K001Card
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExamsScreen(
  viewModel: K001ViewModel,
  onBack: () -> Unit
) {
  val allExams by viewModel.allExams.collectAsStateWithLifecycle()

  var showAddDialog by remember { mutableStateOf(false) }
  var examNameInput by remember { mutableStateOf("") }
  var examSubjectsInput by remember { mutableStateOf("") }
  var examDaysInput by remember { mutableStateOf("14") }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text("Exam Countdown", fontWeight = FontWeight.Bold, color = TextPrimary)
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
      )
    },
    floatingActionButton = {
      FloatingActionButton(
        onClick = {
          examNameInput = ""
          examSubjectsInput = ""
          examDaysInput = "14"
          showAddDialog = true
        },
        containerColor = AccentAmber,
        contentColor = Color.Black,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.testTag("add_exam_fab")
      ) {
        Icon(Icons.Filled.Add, contentDescription = "Add Exam")
      }
    },
    containerColor = DarkBg
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 12.dp)
    ) {
      if (allExams.isEmpty()) {
        EmptyStateView(
          title = "No upcoming exams",
          subtitle = "Add your target exam date to keep track of remaining preparation days.",
          icon = Icons.Filled.Event,
          actionButtonText = "Schedule Exam",
          onActionClick = { showAddDialog = true },
          modifier = Modifier.weight(1f)
        )
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(top = 10.dp, bottom = 96.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          items(allExams, key = { it.id }) { exam ->
            val diff = exam.examDateMillis - System.currentTimeMillis()
            val daysRemaining = TimeUnit.MILLISECONDS.toDays(diff).coerceAtLeast(0)
            val dateStr = SimpleDateFormat("EEEE, MMM dd, yyyy", Locale.getDefault()).format(Date(exam.examDateMillis))

            K001Card(
              backgroundColor = DarkSurface,
              borderColor = if (daysRemaining <= 7) AccentRose.copy(alpha = 0.5f) else AccentAmber.copy(alpha = 0.3f)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                  Box(
                    modifier = Modifier
                      .size(46.dp)
                      .clip(CircleShape)
                      .background(
                        if (daysRemaining <= 7) AccentRose.copy(alpha = 0.15f) else AccentAmber.copy(alpha = 0.15f)
                      ),
                    contentAlignment = Alignment.Center
                  ) {
                    Icon(
                      imageVector = Icons.Filled.Event,
                      contentDescription = null,
                      tint = if (daysRemaining <= 7) AccentRose else AccentAmber,
                      modifier = Modifier.size(22.dp)
                    )
                  }

                  Spacer(modifier = Modifier.width(12.dp))

                  Column {
                    Text(
                      text = exam.name,
                      style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                      )
                    )
                    Text(
                      text = exam.subjects,
                      style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
                      modifier = Modifier.padding(top = 2.dp)
                    )
                    Text(
                      text = dateStr,
                      style = MaterialTheme.typography.labelSmall.copy(color = TextMuted),
                      modifier = Modifier.padding(top = 2.dp)
                    )
                  }
                }

                Column(horizontalAlignment = Alignment.End) {
                  Text(
                    text = "$daysRemaining",
                    style = MaterialTheme.typography.headlineMedium.copy(
                      fontWeight = FontWeight.Black,
                      color = if (daysRemaining <= 7) AccentRose else AccentAmber
                    )
                  )
                  Text(
                    text = "Days Left",
                    style = MaterialTheme.typography.labelSmall.copy(
                      fontWeight = FontWeight.Bold,
                      color = TextSecondary
                    )
                  )

                  IconButton(
                    onClick = { viewModel.deleteExam(exam.id) },
                    modifier = Modifier.size(28.dp).padding(top = 4.dp)
                  ) {
                    Icon(Icons.Outlined.Delete, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(16.dp))
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  // Add Exam Dialog
  if (showAddDialog) {
    AlertDialog(
      onDismissRequest = { showAddDialog = false },
      containerColor = DarkSurfaceElevated,
      title = { Text("Schedule Exam", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = examNameInput,
            onValueChange = { examNameInput = it },
            label = { Text("Exam Name") },
            placeholder = { Text("e.g. Finals or Midterm", color = TextMuted) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentAmber,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = examSubjectsInput,
            onValueChange = { examSubjectsInput = it },
            label = { Text("Subject(s)") },
            placeholder = { Text("e.g. Physics & Chemistry", color = TextMuted) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentAmber,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = examDaysInput,
            onValueChange = { if (it.all { c -> c.isDigit() }) examDaysInput = it },
            label = { Text("Days from now") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentAmber,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (examNameInput.isNotBlank()) {
              val days = examDaysInput.toLongOrNull() ?: 14L
              val dateMillis = System.currentTimeMillis() + TimeUnit.DAYS.toMillis(days)
              viewModel.addExam(
                name = examNameInput.trim(),
                dateMillis = dateMillis,
                subjects = examSubjectsInput.trim().ifBlank { "All Subjects" }
              )
              showAddDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentAmber)
        ) {
          Text("Schedule", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddDialog = false }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }
}
