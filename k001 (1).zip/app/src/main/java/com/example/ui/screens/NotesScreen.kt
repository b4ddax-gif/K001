package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Note
import com.example.ui.components.EmptyStateView
import com.example.ui.components.K001Card
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesScreen(
  viewModel: K001ViewModel,
  onOpenAiNotes: () -> Unit
) {
  val allNotes by viewModel.allNotes.collectAsStateWithLifecycle()
  val allSubjects by viewModel.allSubjects.collectAsStateWithLifecycle()

  var searchQuery by remember { mutableStateOf("") }
  var selectedSubjectFilter by remember { mutableStateOf<String?>(null) }
  var showFavoritesOnly by remember { mutableStateOf(false) }

  var showAddNoteDialog by remember { mutableStateOf(false) }
  var editingNote by remember { mutableStateOf<Note?>(null) }
  var noteTitleInput by remember { mutableStateOf("") }
  var noteContentInput by remember { mutableStateOf("") }
  var noteSubjectInput by remember { mutableStateOf("") }
  var noteChapterInput by remember { mutableStateOf("") }

  val filteredNotes = remember(allNotes, searchQuery, selectedSubjectFilter, showFavoritesOnly) {
    allNotes.filter { note ->
      val matchesSearch = searchQuery.isBlank() ||
          note.title.contains(searchQuery, ignoreCase = true) ||
          note.content.contains(searchQuery, ignoreCase = true)
      val matchesSubject = selectedSubjectFilter == null || note.subjectName == selectedSubjectFilter
      val matchesFav = !showFavoritesOnly || note.isFavorite
      matchesSearch && matchesSubject && matchesFav
    }
  }

  Scaffold(
    floatingActionButton = {
      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        ExtendedFloatingActionButton(
          onClick = onOpenAiNotes,
          containerColor = DarkSurfaceElevated,
          contentColor = AccentViolet,
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("ai_notes_fab")
        ) {
          Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = AccentViolet)
          Spacer(modifier = Modifier.width(6.dp))
          Text("AI Notes", fontWeight = FontWeight.Bold, color = AccentViolet)
        }

        FloatingActionButton(
          onClick = {
            editingNote = null
            noteTitleInput = ""
            noteContentInput = ""
            noteSubjectInput = allSubjects.firstOrNull()?.name ?: ""
            noteChapterInput = ""
            showAddNoteDialog = true
          },
          containerColor = AccentEmerald,
          contentColor = Color.Black,
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("add_note_fab")
        ) {
          Icon(Icons.Filled.Add, contentDescription = "Add Note")
        }
      }
    },
    containerColor = DarkBg
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 12.dp)
    ) {
      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = "Study Notes",
        style = MaterialTheme.typography.headlineMedium.copy(
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Search field
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search your notes...", color = TextMuted) },
        leadingIcon = {
          Icon(Icons.Filled.Search, contentDescription = null, tint = TextSecondary)
        },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Filled.Close, contentDescription = "Clear", tint = TextSecondary)
            }
          }
        },
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = AccentEmerald,
          unfocusedBorderColor = DarkBorder,
          focusedTextColor = TextPrimary,
          unfocusedTextColor = TextPrimary,
          focusedContainerColor = DarkSurface,
          unfocusedContainerColor = DarkSurface
        ),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("notes_search_field")
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Subject filter chips
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        item {
          FilterChip(
            selected = selectedSubjectFilter == null && !showFavoritesOnly,
            onClick = {
              selectedSubjectFilter = null
              showFavoritesOnly = false
            },
            label = { Text("All") },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = AccentEmerald,
              containerColor = DarkSurface
            )
          )
        }

        item {
          FilterChip(
            selected = showFavoritesOnly,
            onClick = { showFavoritesOnly = !showFavoritesOnly },
            label = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Star, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Favorites")
              }
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = AccentAmber.copy(alpha = 0.3f),
              containerColor = DarkSurface
            )
          )
        }

        items(allSubjects) { sub ->
          val isSelected = selectedSubjectFilter == sub.name
          FilterChip(
            selected = isSelected,
            onClick = {
              selectedSubjectFilter = if (isSelected) null else sub.name
            },
            label = { Text(sub.name) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = AccentBlue,
              containerColor = DarkSurface
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (filteredNotes.isEmpty()) {
        EmptyStateView(
          title = "No notes found",
          subtitle = "Create your own concise study summaries or use AI Notes Generator.",
          icon = Icons.Filled.Description,
          actionButtonText = "Write Note",
          onActionClick = {
            editingNote = null
            noteTitleInput = ""
            noteContentInput = ""
            showAddNoteDialog = true
          },
          modifier = Modifier.weight(1f)
        )
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(bottom = 96.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(filteredNotes, key = { it.id }) { note ->
            val dateStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(note.updatedAt))

            K001Card(
              backgroundColor = DarkSurface,
              borderColor = if (note.isPinned) AccentEmerald.copy(alpha = 0.5f) else DarkBorder,
              onClick = {
                editingNote = note
                noteTitleInput = note.title
                noteContentInput = note.content
                noteSubjectInput = note.subjectName
                noteChapterInput = note.chapterName
                showAddNoteDialog = true
              }
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                  if (note.isPinned) {
                    Icon(
                      Icons.Filled.PushPin,
                      contentDescription = "Pinned",
                      tint = AccentEmerald,
                      modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                  }
                  Text(
                    text = note.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                      fontWeight = FontWeight.Bold,
                      color = TextPrimary
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                  IconButton(
                    onClick = { viewModel.togglePinNote(note) },
                    modifier = Modifier.size(28.dp)
                  ) {
                    Icon(
                      imageVector = if (note.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                      contentDescription = "Pin Note",
                      tint = if (note.isPinned) AccentEmerald else TextMuted,
                      modifier = Modifier.size(16.dp)
                    )
                  }
                  IconButton(
                    onClick = { viewModel.toggleFavoriteNote(note) },
                    modifier = Modifier.size(28.dp)
                  ) {
                    Icon(
                      imageVector = if (note.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                      contentDescription = "Favorite Note",
                      tint = if (note.isFavorite) AccentAmber else TextMuted,
                      modifier = Modifier.size(17.dp)
                    )
                  }
                  IconButton(
                    onClick = { viewModel.deleteNote(note.id) },
                    modifier = Modifier.size(28.dp)
                  ) {
                    Icon(
                      Icons.Outlined.Delete,
                      contentDescription = "Delete Note",
                      tint = AccentRose.copy(alpha = 0.7f),
                      modifier = Modifier.size(16.dp)
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(4.dp))

              Text(
                text = note.content,
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
              )

              Spacer(modifier = Modifier.height(8.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                if (note.subjectName.isNotBlank()) {
                  Text(
                    text = note.subjectName,
                    style = MaterialTheme.typography.labelSmall.copy(
                      color = AccentBlue,
                      fontWeight = FontWeight.SemiBold
                    )
                  )
                } else {
                  Spacer(modifier = Modifier.width(4.dp))
                }

                Text(
                  text = dateStr,
                  style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                )
              }
            }
          }
        }
      }
    }
  }

  // Add / Edit Note Dialog
  if (showAddNoteDialog) {
    AlertDialog(
      onDismissRequest = { showAddNoteDialog = false },
      containerColor = DarkSurfaceElevated,
      title = {
        Text(
          text = if (editingNote != null) "Edit Note" else "New Note",
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = noteTitleInput,
            onValueChange = { noteTitleInput = it },
            label = { Text("Title") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentEmerald,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = noteSubjectInput,
            onValueChange = { noteSubjectInput = it },
            label = { Text("Subject (Optional)") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentEmerald,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = noteContentInput,
            onValueChange = { noteContentInput = it },
            label = { Text("Notes Content") },
            minLines = 5,
            maxLines = 10,
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentEmerald,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (noteTitleInput.isNotBlank() && noteContentInput.isNotBlank()) {
              val id = editingNote?.id ?: 0L
              viewModel.saveNote(
                title = noteTitleInput.trim(),
                content = noteContentInput.trim(),
                subjectName = noteSubjectInput.trim(),
                noteId = id
              )
              showAddNoteDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald)
        ) {
          Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddNoteDialog = false }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }
}
