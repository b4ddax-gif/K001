package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Chapter
import com.example.data.model.Subject
import com.example.ui.components.K001Card
import com.example.ui.components.K001ConfirmDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FocusTimerScreen(
  viewModel: K001ViewModel
) {
  val totalSeconds by viewModel.timerTotalSeconds.collectAsStateWithLifecycle()
  val remainingSeconds by viewModel.timerRemainingSeconds.collectAsStateWithLifecycle()
  val isRunning by viewModel.isTimerRunning.collectAsStateWithLifecycle()
  val isPaused by viewModel.isTimerPaused.collectAsStateWithLifecycle()
  val selectedSubject by viewModel.selectedSubject.collectAsStateWithLifecycle()
  val selectedChapter by viewModel.selectedChapter.collectAsStateWithLifecycle()
  val completionEvent by viewModel.sessionCompletionEvent.collectAsStateWithLifecycle()

  val allSubjects by viewModel.allSubjects.collectAsStateWithLifecycle()
  val allChapters by viewModel.allChapters.collectAsStateWithLifecycle()

  var showStopConfirmDialog by remember { mutableStateOf(false) }
  var showCustomDurationDialog by remember { mutableStateOf(false) }
  var customMinutesInput by remember { mutableStateOf("45") }

  var showSubjectPicker by remember { mutableStateOf(false) }
  var showChapterPicker by remember { mutableStateOf(false) }

  val progress = if (totalSeconds > 0) (remainingSeconds.toFloat() / totalSeconds) else 0f
  val animatedProgress by animateFloatAsState(
    targetValue = progress.coerceIn(0f, 1f),
    animationSpec = tween(durationMillis = 500),
    label = "timer_progress"
  )

  val minutes = remainingSeconds / 60
  val seconds = remainingSeconds % 60
  val formattedTime = String.format(Locale.US, "%02d:%02d", minutes, seconds)

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(DarkBg)
      .padding(12.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.SpaceBetween
  ) {
    // Header & Subject/Chapter selector
    Column(
      modifier = Modifier.fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = "Deep Focus Timer",
        style = MaterialTheme.typography.titleLarge.copy(
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Subject / Chapter Selector Card
      K001Card(
        backgroundColor = DarkSurface,
        borderColor = if (isRunning) AccentBlue.copy(alpha = 0.5f) else DarkBorder,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "STUDY TARGET",
              style = MaterialTheme.typography.labelSmall.copy(
                color = AccentBlue,
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Bold
              )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = selectedSubject?.name ?: "Select Subject",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = if (selectedSubject != null) TextPrimary else TextMuted
              ),
              modifier = Modifier.clickable(enabled = !isRunning) {
                showSubjectPicker = true
              }
            )
            Text(
              text = selectedChapter?.name ?: "Select Chapter",
              style = MaterialTheme.typography.bodySmall.copy(
                color = if (selectedChapter != null) AccentBlueLight else TextMuted
              ),
              modifier = Modifier.clickable(enabled = !isRunning) {
                showChapterPicker = true
              }
            )
          }

          if (!isRunning) {
            IconButton(onClick = { showSubjectPicker = true }) {
              Icon(Icons.Filled.Tune, contentDescription = "Change Subject", tint = TextSecondary)
            }
          }
        }
      }
    }

    // Interactive Circular Progress Timer
    Box(
      modifier = Modifier
        .size(260.dp)
        .testTag("focus_timer_circle"),
      contentAlignment = Alignment.Center
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        val strokePx = 14.dp.toPx()
        // Background track
        drawCircle(
          color = ProgressTrack,
          style = Stroke(width = strokePx)
        )
        // Foreground animated countdown arc
        drawArc(
          color = if (isPaused) AccentAmber else AccentBlue,
          startAngle = -90f,
          sweepAngle = animatedProgress * 360f,
          useCenter = false,
          style = Stroke(width = strokePx, cap = StrokeCap.Round)
        )
      }

      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = formattedTime,
          style = MaterialTheme.typography.displayLarge.copy(
            fontWeight = FontWeight.Black,
            fontSize = 48.sp,
            letterSpacing = 1.sp,
            color = TextPrimary
          )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = when {
            !isRunning -> "READY"
            isPaused -> "PAUSED"
            else -> "FOCUSING"
          },
          style = MaterialTheme.typography.labelMedium.copy(
            color = when {
              isPaused -> AccentAmber
              isRunning -> AccentBlue
              else -> TextSecondary
            },
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
          )
        )
      }
    }

    // Preset Selection Chips (when not running)
    AnimatedVisibility(visible = !isRunning) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf(25, 50, 90).forEach { mins ->
          val isSelected = (totalSeconds == mins * 60)
          FilterChip(
            selected = isSelected,
            onClick = { viewModel.setTimerDuration(mins) },
            label = {
              Text(
                text = "$mins min",
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  color = if (isSelected) Color.Black else TextPrimary
                )
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = AccentBlue,
              containerColor = DarkSurfaceElevated
            ),
            border = FilterChipDefaults.filterChipBorder(
              borderColor = if (isSelected) AccentBlue else DarkBorder,
              selectedBorderColor = AccentBlue,
              enabled = true,
              selected = isSelected
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f)
          )
        }

        OutlinedButton(
          onClick = { showCustomDurationDialog = true },
          shape = RoundedCornerShape(10.dp),
          border = ButtonDefaults.outlinedButtonBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkBorder)),
          colors = ButtonDefaults.outlinedButtonColors(containerColor = DarkSurfaceElevated),
          modifier = Modifier.weight(1f)
        ) {
          Text("Custom", color = TextPrimary, fontSize = 12.sp)
        }
      }
    }

    // Controls Row
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 80.dp),
      horizontalArrangement = Arrangement.Center,
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (!isRunning) {
        Button(
          onClick = { viewModel.startTimer() },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier
            .fillMaxWidth(0.7f)
            .height(54.dp)
            .testTag("start_timer_button")
        ) {
          Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.Black)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "START FOCUS",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = Color.Black
            )
          )
        }
      } else {
        // Pause / Resume Button
        Button(
          onClick = {
            if (isPaused) viewModel.resumeTimer() else viewModel.pauseTimer()
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isPaused) AccentBlue else DarkSurfaceElevated
          ),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .weight(1f)
            .height(52.dp)
            .testTag("pause_resume_timer_button")
        ) {
          Icon(
            imageVector = if (isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
            contentDescription = null,
            tint = if (isPaused) Color.Black else TextPrimary
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (isPaused) "RESUME" else "PAUSE",
            fontWeight = FontWeight.Bold,
            color = if (isPaused) Color.Black else TextPrimary
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Stop Button (triggers confirmation dialog)
        OutlinedButton(
          onClick = { showStopConfirmDialog = true },
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.outlinedButtonColors(containerColor = DarkSurface),
          border = ButtonDefaults.outlinedButtonBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AccentRose.copy(alpha = 0.6f))),
          modifier = Modifier
            .weight(1f)
            .height(52.dp)
            .testTag("stop_timer_button")
        ) {
          Icon(Icons.Filled.Stop, contentDescription = null, tint = AccentRose)
          Spacer(modifier = Modifier.width(6.dp))
          Text("STOP", fontWeight = FontWeight.Bold, color = AccentRose)
        }
      }
    }
  }

  // Stop Confirmation Dialog
  if (showStopConfirmDialog) {
    K001ConfirmDialog(
      title = "End Study Session?",
      message = "Are you sure you want to end this study session? Partial progress will be lost.",
      confirmButtonText = "End Session",
      dismissButtonText = "Keep Focusing",
      isDestructive = true,
      onConfirm = {
        viewModel.stopTimer()
        showStopConfirmDialog = false
      },
      onDismiss = { showStopConfirmDialog = false }
    )
  }

  // Session Completed Dialog
  completionEvent?.let { session ->
    AlertDialog(
      onDismissRequest = { viewModel.dismissSessionComplete() },
      containerColor = DarkSurfaceElevated,
      icon = {
        Box(
          modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(AccentEmerald.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = AccentEmerald, modifier = Modifier.size(32.dp))
        }
      },
      title = {
        Text(
          text = "Session Complete!",
          style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          ),
          textAlign = TextAlign.Center
        )
      },
      text = {
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = "Great discipline! You studied for ${session.durationMinutes} minutes.",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
            textAlign = TextAlign.Center
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Subject: ${session.subjectName}",
            style = MaterialTheme.typography.labelLarge.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold)
          )
          Text(
            text = "Chapter: ${session.chapterName}",
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
          )
          Divider(color = DarkBorder, modifier = Modifier.padding(vertical = 4.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("Today Total", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
              Text("${session.todayTotalMinutes}m", style = MaterialTheme.typography.titleMedium.copy(color = AccentBlue, fontWeight = FontWeight.Bold))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("Streak", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
              Text("${session.streak} Days", style = MaterialTheme.typography.titleMedium.copy(color = AccentAmber, fontWeight = FontWeight.Bold))
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = { viewModel.dismissSessionComplete() },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("Continue", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      }
    )
  }

  // Custom Duration Dialog
  if (showCustomDurationDialog) {
    AlertDialog(
      onDismissRequest = { showCustomDurationDialog = false },
      containerColor = DarkSurfaceElevated,
      title = { Text("Custom Duration", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        OutlinedTextField(
          value = customMinutesInput,
          onValueChange = { if (it.all { c -> c.isDigit() }) customMinutesInput = it },
          label = { Text("Minutes") },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AccentBlue,
            unfocusedBorderColor = DarkBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          modifier = Modifier.fillMaxWidth()
        )
      },
      confirmButton = {
        Button(
          onClick = {
            val m = customMinutesInput.toIntOrNull() ?: 25
            if (m > 0) {
              viewModel.setTimerDuration(m)
              showCustomDurationDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
          Text("Set", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showCustomDurationDialog = false }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }

  // Pick Subject Dialog
  if (showSubjectPicker) {
    AlertDialog(
      onDismissRequest = { showSubjectPicker = false },
      containerColor = DarkSurfaceElevated,
      title = { Text("Select Subject", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          if (allSubjects.isEmpty()) {
            Text("No subjects found. Create a subject in Subjects tab first.", color = TextMuted)
          } else {
            allSubjects.forEach { sub ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .clickable {
                    viewModel.setSelectedSubjectAndChapter(sub, null)
                    showSubjectPicker = false
                  }
                  .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(AccentBlue)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(sub.name, color = TextPrimary, fontWeight = FontWeight.Medium)
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showSubjectPicker = false }) {
          Text("Close", color = TextSecondary)
        }
      }
    )
  }

  // Pick Chapter Dialog
  if (showChapterPicker) {
    val chaptersForSub = allChapters.filter { it.subjectId == selectedSubject?.id }
    AlertDialog(
      onDismissRequest = { showChapterPicker = false },
      containerColor = DarkSurfaceElevated,
      title = { Text("Select Chapter", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          if (chaptersForSub.isEmpty()) {
            Text("No chapters found for this subject.", color = TextMuted)
          } else {
            chaptersForSub.forEach { chap ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .clickable {
                    viewModel.setSelectedSubjectAndChapter(selectedSubject, chap)
                    showChapterPicker = false
                  }
                  .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(chap.name, color = TextPrimary, fontWeight = FontWeight.Medium)
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showChapterPicker = false }) {
          Text("Close", color = TextSecondary)
        }
      }
    )
  }
}
