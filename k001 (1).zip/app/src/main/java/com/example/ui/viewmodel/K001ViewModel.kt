package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.*
import com.example.data.local.K001Database
import com.example.data.model.*
import com.example.data.repository.SearchResults
import com.example.data.repository.StudyRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class SessionCompletionData(
  val durationMinutes: Int,
  val subjectName: String,
  val chapterName: String,
  val todayTotalMinutes: Int,
  val streak: Int
)

class K001ViewModel(application: Application) : AndroidViewModel(application) {

  private val repository: StudyRepository

  init {
    val db = K001Database.getDatabase(application)
    repository = StudyRepository(db.k001Dao())
    viewModelScope.launch {
      repository.seedSampleCurriculumIfNeeded()
    }
  }

  // Repository flows
  val userProfile = repository.userProfile.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), null
  )
  val allSubjects = repository.allSubjects.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )
  val allChapters = repository.allChapters.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )
  val allNotes = repository.allNotes.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )
  val allTasks = repository.allTasks.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )
  val allSessions = repository.allSessions.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )
  val latestSession = repository.latestSession.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), null
  )
  val allRevisions = repository.allRevisions.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )
  val allTests = repository.allTests.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )
  val allFlashcards = repository.allFlashcards.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )
  val allExams = repository.allExams.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  // Motivational Quotes
  val quotes = listOf(
    "Discipline is choosing between what you want now, and what you want most.",
    "Small daily improvements over time lead to stunning results.",
    "Success isn't always about greatness. It's about consistency.",
    "Focus on the process, and the outcome will take care of itself.",
    "The secret of getting ahead is getting started.",
    "You don't have to be extreme, just consistent."
  )
  private val _currentQuote = MutableStateFlow(quotes[0])
  val currentQuote = _currentQuote.asStateFlow()

  fun rotateQuote() {
    val next = quotes.random()
    _currentQuote.value = next
  }

  // Focus Timer state
  private val _timerTotalSeconds = MutableStateFlow(25 * 60)
  val timerTotalSeconds = _timerTotalSeconds.asStateFlow()

  private val _timerRemainingSeconds = MutableStateFlow(25 * 60)
  val timerRemainingSeconds = _timerRemainingSeconds.asStateFlow()

  private val _isTimerRunning = MutableStateFlow(false)
  val isTimerRunning = _isTimerRunning.asStateFlow()

  private val _isTimerPaused = MutableStateFlow(false)
  val isTimerPaused = _isTimerPaused.asStateFlow()

  private val _selectedSubject = MutableStateFlow<Subject?>(null)
  val selectedSubject = _selectedSubject.asStateFlow()

  private val _selectedChapter = MutableStateFlow<Chapter?>(null)
  val selectedChapter = _selectedChapter.asStateFlow()

  private val _sessionCompletionEvent = MutableStateFlow<SessionCompletionData?>(null)
  val sessionCompletionEvent = _sessionCompletionEvent.asStateFlow()

  private var timerJob: Job? = null

  fun setTimerDuration(minutes: Int) {
    if (_isTimerRunning.value) return
    val secs = minutes * 60
    _timerTotalSeconds.value = secs
    _timerRemainingSeconds.value = secs
    _isTimerPaused.value = false
  }

  fun setSelectedSubjectAndChapter(subject: Subject?, chapter: Chapter?) {
    _selectedSubject.value = subject
    _selectedChapter.value = chapter
  }

  fun startTimer() {
    if (_isTimerRunning.value) return
    _isTimerRunning.value = true
    _isTimerPaused.value = false

    timerJob = viewModelScope.launch {
      while (_timerRemainingSeconds.value > 0 && _isTimerRunning.value) {
        delay(1000)
        if (!_isTimerPaused.value) {
          _timerRemainingSeconds.value -= 1
        }
      }
      if (_timerRemainingSeconds.value <= 0 && _isTimerRunning.value) {
        completeTimerSession()
      }
    }
  }

  fun pauseTimer() {
    if (_isTimerRunning.value) {
      _isTimerPaused.value = true
    }
  }

  fun resumeTimer() {
    if (_isTimerRunning.value && _isTimerPaused.value) {
      _isTimerPaused.value = false
    }
  }

  fun stopTimer() {
    timerJob?.cancel()
    _isTimerRunning.value = false
    _isTimerPaused.value = false
    _timerRemainingSeconds.value = _timerTotalSeconds.value
  }

  fun resetTimer() {
    stopTimer()
  }

  private fun completeTimerSession() {
    timerJob?.cancel()
    _isTimerRunning.value = false
    _isTimerPaused.value = false

    val durationMin = _timerTotalSeconds.value / 60
    val subName = _selectedSubject.value?.name ?: "General Study"
    val subId = _selectedSubject.value?.id ?: 0L
    val chapName = _selectedChapter.value?.name ?: "Focus Session"
    val chapId = _selectedChapter.value?.id ?: 0L

    viewModelScope.launch {
      val updatedProfile = repository.recordStudySession(
        subjectId = subId,
        subjectName = subName,
        chapterId = chapId,
        chapterName = chapName,
        durationMinutes = durationMin
      )

      val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
      val todayMinutes = allSessions.value
        .filter { it.dateString == today }
        .sumOf { it.durationMinutes } + durationMin

      _sessionCompletionEvent.value = SessionCompletionData(
        durationMinutes = durationMin,
        subjectName = subName,
        chapterName = chapName,
        todayTotalMinutes = todayMinutes,
        streak = updatedProfile.currentStreak
      )
      _timerRemainingSeconds.value = _timerTotalSeconds.value
    }
  }

  fun dismissSessionComplete() {
    _sessionCompletionEvent.value = null
  }

  // Profile operations
  fun completeOnboarding(name: String, dailyGoal: Int, sessionDuration: Int) {
    viewModelScope.launch {
      val current = userProfile.value ?: UserProfile()
      repository.saveProfile(
        current.copy(
          studentName = name.ifBlank { "Student" },
          dailyGoalMinutes = if (dailyGoal > 0) dailyGoal else 120,
          preferredDurationMinutes = if (sessionDuration > 0) sessionDuration else 25,
          isOnboarded = true
        )
      )
      setTimerDuration(if (sessionDuration > 0) sessionDuration else 25)
    }
  }

  fun updateDailyGoal(minutes: Int) {
    viewModelScope.launch {
      repository.updateDailyGoal(minutes)
    }
  }

  fun toggleNotifications(enabled: Boolean) {
    viewModelScope.launch {
      repository.updateNotificationSetting(enabled)
    }
  }

  fun toggleSound(enabled: Boolean) {
    viewModelScope.launch {
      repository.updateSoundSetting(enabled)
    }
  }

  fun resetAllProgress() {
    viewModelScope.launch {
      repository.resetAllData()
    }
  }

  // Subjects & Chapters
  fun addSubject(name: String, colorHex: String = "#38BDF8") {
    viewModelScope.launch {
      repository.addSubject(name, colorHex)
    }
  }

  fun renameSubject(subject: Subject, newName: String) {
    viewModelScope.launch {
      repository.updateSubject(subject.copy(name = newName))
    }
  }

  fun deleteSubject(subjectId: Long) {
    viewModelScope.launch {
      repository.deleteSubject(subjectId)
    }
  }

  fun addChapter(subjectId: Long, name: String, priority: String) {
    viewModelScope.launch {
      repository.addChapter(subjectId, name, priority)
    }
  }

  fun updateChapter(chapter: Chapter) {
    viewModelScope.launch {
      repository.updateChapter(chapter)
    }
  }

  fun deleteChapter(chapterId: Long) {
    viewModelScope.launch {
      repository.deleteChapter(chapterId)
    }
  }

  fun toggleChapterComplete(chapter: Chapter) {
    viewModelScope.launch {
      val nextStatus = if (chapter.status == "COMPLETED") "NOT_STARTED" else "COMPLETED"
      repository.updateChapter(chapter.copy(status = nextStatus))
    }
  }

  // Notes
  fun saveNote(
    title: String,
    content: String,
    subjectId: Long = 0,
    subjectName: String = "",
    chapterId: Long = 0,
    chapterName: String = "",
    noteId: Long = 0
  ) {
    viewModelScope.launch {
      repository.saveNote(
        Note(
          id = noteId,
          title = title,
          content = content,
          subjectId = subjectId,
          subjectName = subjectName,
          chapterId = chapterId,
          chapterName = chapterName
        )
      )
    }
  }

  fun deleteNote(noteId: Long) {
    viewModelScope.launch {
      repository.deleteNote(noteId)
    }
  }

  fun togglePinNote(note: Note) {
    viewModelScope.launch {
      repository.togglePinNote(note)
    }
  }

  fun toggleFavoriteNote(note: Note) {
    viewModelScope.launch {
      repository.toggleFavoriteNote(note)
    }
  }

  // Tasks
  fun addTask(title: String, subjectName: String = "") {
    viewModelScope.launch {
      repository.addTask(title, subjectName)
    }
  }

  fun toggleTask(task: StudyTask) {
    viewModelScope.launch {
      repository.toggleTask(task)
    }
  }

  fun updateTask(task: StudyTask, newTitle: String) {
    viewModelScope.launch {
      repository.updateTask(task.copy(title = newTitle))
    }
  }

  fun deleteTask(taskId: Long) {
    viewModelScope.launch {
      repository.deleteTask(taskId)
    }
  }

  // Revisions
  fun scheduleRevision(chapterId: Long, chapterName: String, subjectName: String, daysAhead: Int) {
    viewModelScope.launch {
      repository.scheduleRevision(chapterId, chapterName, subjectName, daysAhead)
    }
  }

  fun completeRevision(item: RevisionItem, rating: String) {
    viewModelScope.launch {
      repository.completeRevision(item, rating)
    }
  }

  fun deleteRevision(id: Long) {
    viewModelScope.launch {
      repository.deleteRevision(id)
    }
  }

  // Flashcards
  fun addFlashcard(subject: String, chapter: String, front: String, back: String) {
    viewModelScope.launch {
      repository.addFlashcard(
        Flashcard(subjectName = subject, chapterName = chapter, frontText = front, backText = back)
      )
    }
  }

  fun rateFlashcard(card: Flashcard, difficulty: String) {
    viewModelScope.launch {
      repository.updateFlashcard(
        card.copy(
          difficulty = difficulty,
          reviewCount = card.reviewCount + 1,
          lastReviewedAt = System.currentTimeMillis()
        )
      )
    }
  }

  fun deleteFlashcard(id: Long) {
    viewModelScope.launch {
      repository.deleteFlashcard(id)
    }
  }

  // Exams
  fun addExam(name: String, dateMillis: Long, subjects: String) {
    viewModelScope.launch {
      repository.addExam(name, dateMillis, subjects)
    }
  }

  fun deleteExam(id: Long) {
    viewModelScope.launch {
      repository.deleteExam(id)
    }
  }

  // Global Search
  private val _searchQuery = MutableStateFlow("")
  val searchQuery = _searchQuery.asStateFlow()

  private val _searchResults = MutableStateFlow(SearchResults())
  val searchResults = _searchResults.asStateFlow()

  fun performSearch(query: String) {
    _searchQuery.value = query
    viewModelScope.launch {
      _searchResults.value = repository.searchAll(query)
    }
  }

  // AI Assistant
  private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
  val chatMessages = _chatMessages.asStateFlow()

  private val _isAiThinking = MutableStateFlow(false)
  val isAiThinking = _isAiThinking.asStateFlow()

  private val _aiError = MutableStateFlow<String?>(null)
  val aiError = _aiError.asStateFlow()

  fun sendChatMessage(prompt: String) {
    if (prompt.isBlank()) return
    val userMsg = ChatMessage(text = prompt.trim(), isUser = true)
    _chatMessages.value = _chatMessages.value + userMsg
    _isAiThinking.value = true
    _aiError.value = null

    viewModelScope.launch {
      val result = GeminiService.askAssistant(prompt, _chatMessages.value)
      _isAiThinking.value = false
      if (result.isSuccess) {
        val reply = result.getOrNull() ?: ""
        _chatMessages.value = _chatMessages.value + ChatMessage(text = reply, isUser = false)
      } else {
        _aiError.value = result.exceptionOrNull()?.message ?: "AI request failed."
      }
    }
  }

  fun clearChat() {
    _chatMessages.value = emptyList()
    _aiError.value = null
  }

  // AI Notes Generator
  private val _aiNotesResult = MutableStateFlow<String?>(null)
  val aiNotesResult = _aiNotesResult.asStateFlow()

  private val _isGeneratingNotes = MutableStateFlow(false)
  val isGeneratingNotes = _isGeneratingNotes.asStateFlow()

  private val _notesError = MutableStateFlow<String?>(null)
  val notesError = _notesError.asStateFlow()

  fun generateAiNotes(content: String, format: NoteFormat) {
    if (content.isBlank()) return
    _isGeneratingNotes.value = true
    _notesError.value = null
    _aiNotesResult.value = null

    viewModelScope.launch {
      val result = GeminiService.generateNotes(content, format)
      _isGeneratingNotes.value = false
      if (result.isSuccess) {
        _aiNotesResult.value = result.getOrNull()
      } else {
        _notesError.value = result.exceptionOrNull()?.message ?: "Failed to generate notes."
      }
    }
  }

  fun clearAiNotesResult() {
    _aiNotesResult.value = null
    _notesError.value = null
  }

  // AI Test / Quiz Generation
  private val _activeTestQuestions = MutableStateFlow<List<GeneratedMcq>>(emptyList())
  val activeTestQuestions = _activeTestQuestions.asStateFlow()

  private val _currentQuestionIndex = MutableStateFlow(0)
  val currentQuestionIndex = _currentQuestionIndex.asStateFlow()

  private val _userAnswers = MutableStateFlow<Map<Int, Int>>(emptyMap())
  val userAnswers = _userAnswers.asStateFlow()

  private val _isGeneratingQuiz = MutableStateFlow(false)
  val isGeneratingQuiz = _isGeneratingQuiz.asStateFlow()

  private val _quizError = MutableStateFlow<String?>(null)
  val quizError = _quizError.asStateFlow()

  private val _completedTestResult = MutableStateFlow<TestItem?>(null)
  val completedTestResult = _completedTestResult.asStateFlow()

  fun startAiTest(subject: String, chapter: String, count: Int, difficulty: String, onReady: () -> Unit) {
    _isGeneratingQuiz.value = true
    _quizError.value = null
    _userAnswers.value = emptyMap()
    _currentQuestionIndex.value = 0
    _completedTestResult.value = null

    viewModelScope.launch {
      val result = GeminiService.generateMCQs(subject, chapter, count, difficulty)
      _isGeneratingQuiz.value = false
      if (result.isSuccess) {
        val questions = result.getOrNull() ?: emptyList()
        if (questions.isNotEmpty()) {
          _activeTestQuestions.value = questions
          onReady()
        } else {
          _quizError.value = "No questions generated."
        }
      } else {
        _quizError.value = result.exceptionOrNull()?.message ?: "Failed to generate test questions."
      }
    }
  }

  fun startManualTest(questions: List<GeneratedMcq>, onReady: () -> Unit) {
    _activeTestQuestions.value = questions
    _userAnswers.value = emptyMap()
    _currentQuestionIndex.value = 0
    _completedTestResult.value = null
    onReady()
  }

  fun selectAnswer(questionIndex: Int, optionIndex: Int) {
    val map = _userAnswers.value.toMutableMap()
    map[questionIndex] = optionIndex
    _userAnswers.value = map
  }

  fun nextQuestion() {
    if (_currentQuestionIndex.value < _activeTestQuestions.value.size - 1) {
      _currentQuestionIndex.value += 1
    }
  }

  fun previousQuestion() {
    if (_currentQuestionIndex.value > 0) {
      _currentQuestionIndex.value -= 1
    }
  }

  fun submitActiveTest(
    subjectName: String,
    chapterName: String,
    timeTakenSeconds: Int,
    onSubmitted: (Long) -> Unit
  ) {
    val questions = _activeTestQuestions.value
    val answers = _userAnswers.value
    var correct = 0
    var wrong = 0
    var skipped = 0

    val qJsonArray = JSONArray()
    val ansJsonArray = JSONArray()

    for (i in questions.indices) {
      val q = questions[i]
      val selected = answers[i]
      if (selected == null) {
        skipped += 1
      } else if (selected == q.correctOptionIndex) {
        correct += 1
      } else {
        wrong += 1
      }

      val qObj = JSONObject()
      qObj.put("question", q.question)
      qObj.put("options", JSONArray(q.options))
      qObj.put("correctOptionIndex", q.correctOptionIndex)
      qObj.put("explanation", q.explanation)
      qJsonArray.put(qObj)

      val aObj = JSONObject()
      aObj.put("index", i)
      aObj.put("selected", selected ?: -1)
      ansJsonArray.put(aObj)
    }

    val total = questions.size
    val score = correct
    val percentage = if (total > 0) (correct * 100) / total else 0

    val testItem = TestItem(
      title = "$subjectName: $chapterName Quiz",
      subjectName = subjectName,
      chapterName = chapterName,
      totalQuestions = total,
      score = score,
      percentage = percentage,
      correctCount = correct,
      wrongCount = wrong,
      skippedCount = skipped,
      timeTakenSeconds = timeTakenSeconds,
      timestamp = System.currentTimeMillis(),
      questionsJson = qJsonArray.toString(),
      userAnswersJson = ansJsonArray.toString()
    )

    viewModelScope.launch {
      val id = repository.saveTestResult(testItem)
      val saved = testItem.copy(id = id)
      _completedTestResult.value = saved
      onSubmitted(id)
    }
  }
}
