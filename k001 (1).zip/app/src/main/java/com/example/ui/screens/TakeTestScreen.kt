package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.K001Card
import com.example.ui.components.K001ConfirmDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TakeTestScreen(
  viewModel: K001ViewModel,
  onBack: () -> Unit,
  onTestSubmitted: (Long) -> Unit
) {
  val questions by viewModel.activeTestQuestions.collectAsStateWithLifecycle()
  val currentIndex by viewModel.currentQuestionIndex.collectAsStateWithLifecycle()
  val userAnswers by viewModel.userAnswers.collectAsStateWithLifecycle()

  var elapsedSeconds by remember { mutableIntStateOf(0) }
  var showSubmitConfirm by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    while (true) {
      delay(1000)
      elapsedSeconds += 1
    }
  }

  val totalQuestions = questions.size

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text("Assessment", fontWeight = FontWeight.Bold, color = TextPrimary)
        },
        actions = {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(end = 16.dp)
          ) {
            Icon(Icons.Filled.Timer, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            val m = elapsedSeconds / 60
            val s = elapsedSeconds % 60
            Text(
              text = String.format("%02d:%02d", m, s),
              style = MaterialTheme.typography.labelLarge.copy(color = AccentAmber, fontWeight = FontWeight.Bold)
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
      )
    },
    containerColor = DarkBg
  ) { padding ->
    if (questions.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(padding),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("No active test questions found.", color = TextSecondary)
          Spacer(modifier = Modifier.height(16.dp))
          Button(onClick = onBack) { Text("Go Back") }
        }
      }
      return@Scaffold
    }

    val currentQ = questions[currentIndex]
    val selectedOption = userAnswers[currentIndex]

    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(16.dp)
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {
        // Question tracker & Linear Progress
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "QUESTION ${currentIndex + 1} OF $totalQuestions",
            style = MaterialTheme.typography.labelMedium.copy(
              color = AccentBlue,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp
            )
          )
          Text(
            text = "${userAnswers.size} answered",
            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        LinearProgressIndicator(
          progress = { (currentIndex + 1).toFloat() / totalQuestions },
          modifier = Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp)),
          color = AccentBlue,
          trackColor = ProgressTrack
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Question Card
        K001Card(
          backgroundColor = DarkSurface,
          borderColor = DarkBorder
        ) {
          Text(
            text = currentQ.question,
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.SemiBold,
              color = TextPrimary,
              lineHeight = 24.sp
            )
          )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Options
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          currentQ.options.forEachIndexed { optIndex, optionText ->
            val isSelected = selectedOption == optIndex
            val optionLetter = ('A'.code + optIndex).toChar()

            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .border(
                  width = if (isSelected) 1.5.dp else 1.dp,
                  color = if (isSelected) AccentBlue else DarkBorder,
                  shape = RoundedCornerShape(12.dp)
                )
                .clickable {
                  viewModel.selectAnswer(currentIndex, optIndex)
                }
                .testTag("test_option_${optIndex}"),
              colors = CardDefaults.cardColors(
                containerColor = if (isSelected) AccentBlue.copy(alpha = 0.12f) else DarkSurface
              )
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) AccentBlue else DarkSurfaceElevated)
                    .border(1.dp, if (isSelected) AccentBlue else DarkBorder, CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = "$optionLetter",
                    style = MaterialTheme.typography.labelMedium.copy(
                      fontWeight = FontWeight.Bold,
                      color = if (isSelected) Color.Black else TextPrimary
                    )
                  )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Text(
                  text = optionText,
                  style = MaterialTheme.typography.bodyMedium.copy(
                    color = if (isSelected) TextPrimary else TextSecondary
                  ),
                  modifier = Modifier.weight(1f)
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Bottom Navigation & Submit
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          OutlinedButton(
            onClick = { viewModel.previousQuestion() },
            enabled = currentIndex > 0,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Previous")
          }

          Spacer(modifier = Modifier.width(12.dp))

          if (currentIndex < totalQuestions - 1) {
            Button(
              onClick = { viewModel.nextQuestion() },
              colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
              border = ButtonDefaults.outlinedButtonBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkBorder)),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f)
            ) {
              Text("Next", color = TextPrimary)
              Spacer(modifier = Modifier.width(4.dp))
              Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(16.dp))
            }
          } else {
            Button(
              onClick = { showSubmitConfirm = true },
              colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Filled.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Submit Test", color = Color.Black, fontWeight = FontWeight.Bold)
            }
          }
        }

        if (currentIndex < totalQuestions - 1) {
          TextButton(
            onClick = { showSubmitConfirm = true },
            modifier = Modifier.align(Alignment.CenterHorizontally)
          ) {
            Text("Finish & Submit Now", color = AccentAmber, fontSize = 13.sp)
          }
        }
      }
    }
  }

  if (showSubmitConfirm) {
    val unansweredCount = totalQuestions - userAnswers.size
    val message = if (unansweredCount > 0) {
      "You have $unansweredCount unanswered question(s). Are you sure you want to submit your test now?"
    } else {
      "Are you sure you want to submit your test and view your score and explanations?"
    }

    K001ConfirmDialog(
      title = "Submit Assessment?",
      message = message,
      confirmButtonText = "Submit Now",
      dismissButtonText = "Review Answers",
      onConfirm = {
        showSubmitConfirm = false
        viewModel.submitActiveTest(
          subjectName = "Assessment",
          chapterName = "Practice Quiz",
          timeTakenSeconds = elapsedSeconds,
          onSubmitted = onTestSubmitted
        )
      },
      onDismiss = { showSubmitConfirm = false }
    )
  }
}
