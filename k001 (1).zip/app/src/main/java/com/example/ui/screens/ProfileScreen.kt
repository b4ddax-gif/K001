package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.ai.GeminiService
import com.example.ui.components.K001Card
import com.example.ui.components.K001ConfirmDialog
import com.example.ui.components.StreakBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
  viewModel: K001ViewModel,
  onNavigateToAnalytics: () -> Unit,
  onNavigateToExams: () -> Unit,
  onNavigateToFlashcards: () -> Unit
) {
  val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
  val allSessions by viewModel.allSessions.collectAsStateWithLifecycle()

  var showGoalDialog by remember { mutableStateOf(false) }
  var goalInput by remember { mutableStateOf("${userProfile?.dailyGoalMinutes ?: 120}") }

  var showResetConfirm by remember { mutableStateOf(false) }

  val totalMins = remember(allSessions) { allSessions.sumOf { it.durationMinutes } }
  val totalHours = String.format(java.util.Locale.US, "%.1f", totalMins / 60f)

  val isKeySet = GeminiService.isApiKeyAvailable()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(DarkBg)
      .verticalScroll(rememberScrollState())
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Spacer(modifier = Modifier.height(10.dp))

    Text(
      text = "Student Profile",
      style = MaterialTheme.typography.headlineMedium.copy(
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )
    )

    // User Profile Card
    K001Card(
      backgroundColor = DarkSurface,
      borderColor = DarkBorder
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(60.dp)
            .clip(CircleShape)
            .background(DarkSurfaceElevated)
            .border(1.dp, AccentBlue.copy(alpha = 0.5f), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Image(
            painter = painterResource(id = R.drawable.k001_icon),
            contentDescription = null,
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
          )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = userProfile?.studentName?.ifBlank { "Scholar" } ?: "Scholar",
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
          Text(
            text = "K001 Academic Scholar",
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
          )
          Spacer(modifier = Modifier.height(6.dp))
          StreakBadge(streakDays = userProfile?.currentStreak ?: 0)
        }
      }

      Spacer(modifier = Modifier.height(16.dp))
      Divider(color = DarkBorder)
      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceAround
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "${totalHours}h", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = AccentBlue))
          Text(text = "Total Study", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "${userProfile?.dailyGoalMinutes ?: 120}m", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = AccentEmerald))
          Text(text = "Daily Target", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "${userProfile?.longestStreak ?: 0}d", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = AccentAmber))
          Text(text = "Best Streak", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
        }
      }
    }

    // Quick Modules
    Text(
      text = "Academic Modules",
      style = MaterialTheme.typography.titleMedium.copy(
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )
    )

    K001Card(backgroundColor = DarkSurface) {
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        ProfileNavRow(
          title = "Detailed Analytics & Consistency",
          subtitle = "View your 7-day study breakdown and metrics",
          icon = Icons.Filled.TrendingUp,
          iconTint = AccentBlue,
          onClick = onNavigateToAnalytics
        )
        Divider(color = DarkBorder, modifier = Modifier.padding(vertical = 4.dp))
        ProfileNavRow(
          title = "Flashcard Decks & Spaced Recall",
          subtitle = "Practice cards and test active retention",
          icon = Icons.Filled.Style,
          iconTint = AccentViolet,
          onClick = onNavigateToFlashcards
        )
        Divider(color = DarkBorder, modifier = Modifier.padding(vertical = 4.dp))
        ProfileNavRow(
          title = "Upcoming Exams Countdown",
          subtitle = "Track days remaining for board and term exams",
          icon = Icons.Filled.Event,
          iconTint = AccentAmber,
          onClick = onNavigateToExams
        )
      }
    }

    // Study Preferences & Settings
    Text(
      text = "Study Preferences",
      style = MaterialTheme.typography.titleMedium.copy(
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )
    )

    K001Card(backgroundColor = DarkSurface) {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Daily goal setting
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              goalInput = "${userProfile?.dailyGoalMinutes ?: 120}"
              showGoalDialog = true
            }
            .padding(vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("Daily Goal", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = TextPrimary))
            Text("Set daily target minutes", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
          }
          Text(
            text = "${userProfile?.dailyGoalMinutes ?: 120} min",
            style = MaterialTheme.typography.labelLarge.copy(color = AccentBlue, fontWeight = FontWeight.Bold)
          )
        }

        Divider(color = DarkBorder)

        // Notifications setting
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("Study Reminders", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = TextPrimary))
            Text("Daily habit and revision alerts", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
          }
          Switch(
            checked = userProfile?.notificationsEnabled ?: true,
            onCheckedChange = { viewModel.toggleNotifications(it) },
            colors = SwitchDefaults.colors(
              checkedThumbColor = Color.Black,
              checkedTrackColor = AccentBlue
            )
          )
        }

        Divider(color = DarkBorder)

        // Sound setting
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("Focus Bell & Sounds", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = TextPrimary))
            Text("Chime on timer completion", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
          }
          Switch(
            checked = userProfile?.soundEnabled ?: true,
            onCheckedChange = { viewModel.toggleSound(it) },
            colors = SwitchDefaults.colors(
              checkedThumbColor = Color.Black,
              checkedTrackColor = AccentBlue
            )
          )
        }
      }
    }

    // AI Configuration status
    Text(
      text = "AI Infrastructure",
      style = MaterialTheme.typography.titleMedium.copy(
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )
    )

    K001Card(
      backgroundColor = DarkSurface,
      borderColor = if (isKeySet) AccentEmerald.copy(alpha = 0.3f) else AccentAmber.copy(alpha = 0.3f)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = if (isKeySet) Icons.Filled.CheckCircle else Icons.Filled.Info,
            contentDescription = null,
            tint = if (isKeySet) AccentEmerald else AccentAmber
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = if (isKeySet) "Gemini API Active" else "API Key Pending",
              style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
            )
            Text(
              text = if (isKeySet) "gemini-3.5-flash ready for assistance" else "Set GEMINI_API_KEY in Secrets panel",
              style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
            )
          }
        }
      }
    }

    // Reset Data CTA
    OutlinedButton(
      onClick = { showResetConfirm = true },
      colors = ButtonDefaults.outlinedButtonColors(containerColor = DarkSurface),
      border = ButtonDefaults.outlinedButtonBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AccentRose.copy(alpha = 0.5f))),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier
        .fillMaxWidth()
        .height(48.dp)
        .testTag("reset_data_button")
    ) {
      Icon(Icons.Outlined.RestartAlt, contentDescription = null, tint = AccentRose)
      Spacer(modifier = Modifier.width(8.dp))
      Text("Reset Application Data", color = AccentRose, fontWeight = FontWeight.SemiBold)
    }

    // App Branding Footer
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 16.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(
        text = "K001 • Version 1.0.0",
        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
      )
      Text(
        text = "Study Smarter. Stay Consistent.",
        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
      )
    }

    Spacer(modifier = Modifier.height(72.dp))
  }

  // Daily Goal Dialog
  if (showGoalDialog) {
    AlertDialog(
      onDismissRequest = { showGoalDialog = false },
      containerColor = DarkSurfaceElevated,
      title = { Text("Daily Study Goal", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        OutlinedTextField(
          value = goalInput,
          onValueChange = { if (it.all { c -> c.isDigit() }) goalInput = it },
          label = { Text("Minutes per day") },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AccentBlue,
            unfocusedBorderColor = DarkBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          modifier = Modifier.fillMaxWidth()
        )
      },
      confirmButton = {
        Button(
          onClick = {
            val mins = goalInput.toIntOrNull() ?: 120
            if (mins > 0) {
              viewModel.updateDailyGoal(mins)
              showGoalDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
          Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showGoalDialog = false }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }

  // Reset Confirmation
  if (showResetConfirm) {
    K001ConfirmDialog(
      title = "Reset All Data?",
      message = "This will permanently delete all your subjects, chapters, notes, sessions, streak records, and test results. Are you sure?",
      confirmButtonText = "Reset Everything",
      dismissButtonText = "Cancel",
      isDestructive = true,
      onConfirm = {
        viewModel.resetAllProgress()
        showResetConfirm = false
      },
      onDismiss = { showResetConfirm = false }
    )
  }
}

@Composable
fun ProfileNavRow(
  title: String,
  subtitle: String,
  icon: ImageVector,
  iconTint: Color,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .clickable(onClick = onClick)
      .padding(vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Box(
      modifier = Modifier
        .size(36.dp)
        .clip(CircleShape)
        .background(iconTint.copy(alpha = 0.15f)),
      contentAlignment = Alignment.Center
    ) {
      Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
    }
    Spacer(modifier = Modifier.width(12.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = TextPrimary))
      Text(subtitle, style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
    }
    Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextMuted)
  }
}
