package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// High Density Theme Color Palette
val DarkBg = Color(0xFF0A0A0A)
val DarkSurface = Color(0xFF141414)
val DarkSurfaceVariant = Color(0xFF191919)
val DarkSurfaceElevated = Color(0xFF202020)
val DarkBorder = Color(0xFF262626)
val DarkBorderLight = Color(0xFF333333)

// Accents - High Density vibrant functional palette
val AccentBlue = Color(0xFF38BDF8) // Sky cyan
val AccentBlueLight = Color(0xFF7DD3FC)
val AccentPrimary = Color(0xFF6366F1) // High Density Indigo
val AccentPrimaryLight = Color(0xFF818CF8)
val AccentEmerald = Color(0xFF10B981) // Consistent streak / success
val AccentAmber = Color(0xFFF59E0B) // Warning / focus flame
val AccentRose = Color(0xFFF43F5E) // High priority / overdue
val AccentViolet = Color(0xFF8B5CF6) // AI accent

// Text colors - Slate scale from High Density HTML (slate-200, slate-400, slate-500)
val TextPrimary = Color(0xFFE2E8F0) // slate-200
val TextSecondary = Color(0xFF94A3B8) // slate-400
val TextMuted = Color(0xFF64748B) // slate-500
val TextWhite = Color(0xFFFFFFFF)

// Component highlights
val CardGlow = Color(0x146366F1)
val ProgressTrack = Color(0xFF1E1E1E)

