package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.EmptyStateView
import com.example.ui.components.K001Card
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
  viewModel: K001ViewModel,
  onBack: () -> Unit,
  onNavigateToChapter: (Long) -> Unit,
  onNavigateToNotes: () -> Unit,
  onNavigateToSubjects: () -> Unit
) {
  val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
  val results by viewModel.searchResults.collectAsStateWithLifecycle()

  var input by remember { mutableStateOf(searchQuery) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          OutlinedTextField(
            value = input,
            onValueChange = {
              input = it
              viewModel.performSearch(it)
            },
            placeholder = { Text("Search subjects, chapters, notes...", color = TextMuted, fontSize = 14.sp) },
            singleLine = true,
            trailingIcon = {
              if (input.isNotEmpty()) {
                IconButton(onClick = {
                  input = ""
                  viewModel.performSearch("")
                }) {
                  Icon(Icons.Filled.Close, contentDescription = "Clear", tint = TextSecondary)
                }
              }
            },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentBlue,
              unfocusedBorderColor = Color.Transparent,
              focusedContainerColor = DarkSurfaceElevated,
              unfocusedContainerColor = DarkSurfaceElevated,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("global_search_input")
          )
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
      )
    },
    containerColor = DarkBg
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 12.dp)
    ) {
      if (input.isBlank()) {
        EmptyStateView(
          title = "Global Academic Search",
          subtitle = "Type any keyword to search across subjects, topics, notes, and past tests.",
          icon = Icons.Filled.Search,
          modifier = Modifier.weight(1f)
        )
      } else if (
        results.subjects.isEmpty() &&
        results.chapters.isEmpty() &&
        results.notes.isEmpty() &&
        results.tests.isEmpty()
      ) {
        EmptyStateView(
          title = "No matches found",
          subtitle = "Try searching for a different keyword or topic.",
          icon = Icons.Filled.SearchOff,
          modifier = Modifier.weight(1f)
        )
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(top = 10.dp, bottom = 48.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // Subjects results
          if (results.subjects.isNotEmpty()) {
            item {
              SectionHeader(title = "Subjects (${results.subjects.size})", color = AccentBlue)
            }
            items(results.subjects) { sub ->
              K001Card(
                backgroundColor = DarkSurface,
                onClick = onNavigateToSubjects
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Filled.CollectionsBookmark, contentDescription = null, tint = AccentBlue)
                  Spacer(modifier = Modifier.width(10.dp))
                  Text(sub.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary))
                }
              }
            }
          }

          // Chapters results
          if (results.chapters.isNotEmpty()) {
            item {
              SectionHeader(title = "Chapters (${results.chapters.size})", color = AccentEmerald)
            }
            items(results.chapters) { chap ->
              K001Card(
                backgroundColor = DarkSurface,
                onClick = { onNavigateToChapter(chap.id) }
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.MenuBook, contentDescription = null, tint = AccentEmerald)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                      Text(chap.name, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TextPrimary))
                      Text("${chap.totalStudyMinutes}m studied", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                    }
                  }
                  Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextMuted)
                }
              }
            }
          }

          // Notes results
          if (results.notes.isNotEmpty()) {
            item {
              SectionHeader(title = "Notes (${results.notes.size})", color = AccentViolet)
            }
            items(results.notes) { note ->
              K001Card(
                backgroundColor = DarkSurface,
                onClick = onNavigateToNotes
              ) {
                Text(note.title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary))
                Spacer(modifier = Modifier.height(4.dp))
                Text(note.content, style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary), maxLines = 2)
              }
            }
          }

          // Tests results
          if (results.tests.isNotEmpty()) {
            item {
              SectionHeader(title = "Assessments (${results.tests.size})", color = AccentAmber)
            }
            items(results.tests) { test ->
              K001Card(backgroundColor = DarkSurface) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Text(test.title, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TextPrimary))
                    Text("${test.correctCount}/${test.totalQuestions} correct", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                  }
                  Text("${test.percentage}%", style = MaterialTheme.typography.titleMedium.copy(color = AccentAmber, fontWeight = FontWeight.Bold))
                }
              }
            }
          }
        }
      }
    }
  }
}
