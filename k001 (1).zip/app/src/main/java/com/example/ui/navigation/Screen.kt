package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
  val route: String,
  val title: String,
  val selectedIcon: ImageVector? = null,
  val unselectedIcon: ImageVector? = null
) {
  object Onboarding : Screen("onboarding", "Onboarding")
  object Home : Screen("home", "Home", Icons.Filled.Home, Icons.Outlined.Home)
  object Subjects : Screen("subjects", "Subjects", Icons.Filled.Book, Icons.Outlined.Book)
  object Focus : Screen("focus", "Focus", Icons.Filled.Timer, Icons.Outlined.Timer)
  object Notes : Screen("notes", "Notes", Icons.Filled.Description, Icons.Outlined.Description)
  object Profile : Screen("profile", "Profile", Icons.Filled.Person, Icons.Outlined.Person)

  // Contextual screens
  object ChapterDetail : Screen("chapter_detail/{chapterId}", "Chapter") {
    fun createRoute(chapterId: Long) = "chapter_detail/$chapterId"
  }
  object AiAssistant : Screen("ai_assistant", "AI Assistant")
  object AiNotes : Screen("ai_notes", "AI Notes")
  object Tests : Screen("tests", "Tests")
  object TakeTest : Screen("take_test/{mode}", "Test") {
    fun createRoute(mode: String = "ai") = "take_test/$mode"
  }
  object TestResult : Screen("test_result/{testId}", "Test Result") {
    fun createRoute(testId: Long) = "test_result/$testId"
  }
  object Revision : Screen("revision", "Revision")
  object Flashcards : Screen("flashcards", "Flashcards")
  object ReviewFlashcards : Screen("review_flashcards", "Flashcard Review")
  object Analytics : Screen("analytics", "Analytics")
  object Exams : Screen("exams", "Exam Countdown")
  object Search : Screen("search", "Search")
}

val BottomNavItems = listOf(
  Screen.Home,
  Screen.Subjects,
  Screen.Focus,
  Screen.Notes,
  Screen.Profile
)
