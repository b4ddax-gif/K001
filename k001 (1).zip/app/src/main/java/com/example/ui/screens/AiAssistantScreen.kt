package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ai.ChatMessage
import com.example.ui.components.K001Card
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantScreen(
  viewModel: K001ViewModel,
  onBack: () -> Unit
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val listState = rememberLazyListState()

  val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
  val isThinking by viewModel.isAiThinking.collectAsStateWithLifecycle()
  val aiError by viewModel.aiError.collectAsStateWithLifecycle()

  var inputText by remember { mutableStateOf("") }
  var noteToSaveTitle by remember { mutableStateOf("") }
  var noteToSaveContent by remember { mutableStateOf<String?>(null) }

  val promptChips = listOf(
    "Explain Concept",
    "Solve Problem",
    "Summarize Chapter",
    "Create Study Plan",
    "Generate Practice Questions"
  )

  LaunchedEffect(messages.size, isThinking) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.size - 1)
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(AccentViolet.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = AccentViolet, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text("AI Study Assistant", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 18.sp)
              Text("Powered by Gemini", style = MaterialTheme.typography.labelSmall.copy(color = AccentViolet))
            }
          }
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
          }
        },
        actions = {
          if (messages.isNotEmpty()) {
            IconButton(onClick = { viewModel.clearChat() }) {
              Icon(Icons.Outlined.DeleteSweep, contentDescription = "Clear Chat", tint = TextSecondary)
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
      )
    },
    containerColor = DarkBg
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .navigationBarsPadding()
    ) {
      // Chat Messages Area
      if (messages.isEmpty() && !isThinking) {
        Column(
          modifier = Modifier
            .weight(1f)
            .padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Box(
            modifier = Modifier
              .size(60.dp)
              .clip(CircleShape)
              .background(DarkSurfaceElevated)
              .border(1.dp, AccentViolet.copy(alpha = 0.5f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = AccentViolet, modifier = Modifier.size(30.dp))
          }
          Spacer(modifier = Modifier.height(16.dp))
          Text(
            text = "How can I assist your study session today?",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
          Text(
            text = "Ask questions, get step-by-step problem explanations, or draft study strategies.",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
            modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
          )

          // Prompt Chips
          Text(
            text = "Suggested Prompts",
            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, letterSpacing = 1.sp)
          )
          Spacer(modifier = Modifier.height(8.dp))

          Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            promptChips.forEach { chip ->
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(12.dp))
                  .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
                  .clickable {
                    val promptText = when (chip) {
                      "Explain Concept" -> "Explain the concept of entropy in thermodynamics with intuitive examples."
                      "Solve Problem" -> "Step-by-step, how do I solve this integral: ∫ x * e^x dx ?"
                      "Summarize Chapter" -> "Give me a high-yield summary of Newton's Laws of Motion with key equations."
                      "Create Study Plan" -> "Help me plan a 7-day revision schedule for upcoming final exams."
                      else -> "Generate 3 challenging multiple-choice practice questions on Data Structures."
                    }
                    viewModel.sendChatMessage(promptText)
                  },
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = AccentViolet, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(chip, style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary))
                }
              }
            }
          }
        }
      } else {
        LazyColumn(
          state = listState,
          modifier = Modifier
            .weight(1f)
            .padding(horizontal = 16.dp),
          contentPadding = PaddingValues(vertical = 12.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          items(messages) { msg ->
            ChatMessageBubble(
              message = msg,
              onCopy = {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("AI Response", msg.text))
                Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
              },
              onSaveToNotes = {
                noteToSaveContent = msg.text
                noteToSaveTitle = "AI Note - ${msg.text.take(24)}..."
              }
            )
          }

          if (isThinking) {
            item {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                CircularProgressIndicator(
                  modifier = Modifier.size(20.dp),
                  color = AccentViolet,
                  strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                  text = "Thinking...",
                  style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                )
              }
            }
          }

          aiError?.let { err ->
            item {
              K001Card(
                backgroundColor = AccentRose.copy(alpha = 0.1f),
                borderColor = AccentRose.copy(alpha = 0.4f)
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = AccentRose)
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = err,
                    style = MaterialTheme.typography.bodySmall.copy(color = AccentRose)
                  )
                }
              }
            }
          }
        }
      }

      // Input Bottom Row
      Surface(
        color = DarkSurface,
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkBorder))
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = inputText,
            onValueChange = { inputText = it },
            placeholder = { Text("Ask anything...", color = TextMuted) },
            maxLines = 4,
            shape = RoundedCornerShape(20.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentViolet,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary,
              focusedContainerColor = DarkSurfaceVariant,
              unfocusedContainerColor = DarkSurfaceVariant
            ),
            modifier = Modifier
              .weight(1f)
              .testTag("ai_assistant_input")
          )

          Spacer(modifier = Modifier.width(8.dp))

          IconButton(
            onClick = {
              if (inputText.isNotBlank() && !isThinking) {
                viewModel.sendChatMessage(inputText.trim())
                inputText = ""
              }
            },
            enabled = inputText.isNotBlank() && !isThinking,
            modifier = Modifier
              .size(46.dp)
              .clip(CircleShape)
              .background(if (inputText.isNotBlank() && !isThinking) AccentViolet else DarkSurfaceElevated)
              .testTag("send_ai_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.Send,
              contentDescription = "Send",
              tint = if (inputText.isNotBlank() && !isThinking) Color.White else TextMuted
            )
          }
        }
      }
    }
  }

  // Save to Notes Dialog
  noteToSaveContent?.let { content ->
    AlertDialog(
      onDismissRequest = { noteToSaveContent = null },
      containerColor = DarkSurfaceElevated,
      title = { Text("Save to Notes", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = noteToSaveTitle,
            onValueChange = { noteToSaveTitle = it },
            label = { Text("Note Title") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentBlue,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (noteToSaveTitle.isNotBlank()) {
              viewModel.saveNote(
                title = noteToSaveTitle.trim(),
                content = content
              )
              noteToSaveContent = null
              Toast.makeText(context, "Saved to Notes!", Toast.LENGTH_SHORT).show()
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
          Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { noteToSaveContent = null }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }
}

@Composable
fun ChatMessageBubble(
  message: ChatMessage,
  onCopy: () -> Unit,
  onSaveToNotes: () -> Unit
) {
  val isUser = message.isUser

  Column(
    modifier = Modifier.fillMaxWidth(),
    horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
  ) {
    Card(
      shape = RoundedCornerShape(
        topStart = 16.dp,
        topEnd = 16.dp,
        bottomStart = if (isUser) 16.dp else 4.dp,
        bottomEnd = if (isUser) 4.dp else 16.dp
      ),
      colors = CardDefaults.cardColors(
        containerColor = if (isUser) AccentBlue.copy(alpha = 0.2f) else DarkSurfaceVariant
      ),
      border = CardDefaults.outlinedCardBorder().copy(
        brush = androidx.compose.ui.graphics.SolidColor(if (isUser) AccentBlue.copy(alpha = 0.4f) else DarkBorder)
      ),
      modifier = Modifier.widthIn(max = 320.dp)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Text(
          text = message.text,
          style = MaterialTheme.typography.bodyMedium.copy(
            color = TextPrimary,
            lineHeight = 22.sp
          )
        )

        if (!isUser) {
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
          ) {
            IconButton(onClick = onCopy, modifier = Modifier.size(28.dp)) {
              Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy", tint = TextSecondary, modifier = Modifier.size(15.dp))
            }
            Spacer(modifier = Modifier.width(4.dp))
            IconButton(onClick = onSaveToNotes, modifier = Modifier.size(28.dp)) {
              Icon(Icons.Outlined.BookmarkAdd, contentDescription = "Save to Notes", tint = AccentViolet, modifier = Modifier.size(17.dp))
            }
          }
        }
      }
    }
  }
}
