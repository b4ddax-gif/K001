package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.RevisionItem
import com.example.ui.components.EmptyStateView
import com.example.ui.components.K001Card
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RevisionScreen(
  viewModel: K001ViewModel,
  onBack: () -> Unit
) {
  val allRevisions by viewModel.allRevisions.collectAsStateWithLifecycle()
  val allSubjects by viewModel.allSubjects.collectAsStateWithLifecycle()
  val allChapters by viewModel.allChapters.collectAsStateWithLifecycle()

  var showScheduleDialog by remember { mutableStateOf(false) }
  var selectedSubjectName by remember { mutableStateOf("") }
  var selectedChapterName by remember { mutableStateOf("") }
  var selectedIntervalDays by remember { mutableIntStateOf(3) }

  var completingRevisionItem by remember { mutableStateOf<RevisionItem?>(null) }

  val now = System.currentTimeMillis()
  val startOfToday = remember {
    val cal = Calendar.getInstance()
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    cal.timeInMillis
  }
  val endOfToday = startOfToday + TimeUnit.DAYS.toMillis(1)

  val dueToday = allRevisions.filter { !it.isCompleted && it.scheduledDate in startOfToday..endOfToday }
  val overdue = allRevisions.filter { !it.isCompleted && it.scheduledDate < startOfToday }
  val upcoming = allRevisions.filter { !it.isCompleted && it.scheduledDate > endOfToday }
  val completed = allRevisions.filter { it.isCompleted }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text("Spaced Repetition & Revision", fontWeight = FontWeight.Bold, color = TextPrimary)
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
      )
    },
    floatingActionButton = {
      FloatingActionButton(
        onClick = {
          selectedSubjectName = allSubjects.firstOrNull()?.name ?: ""
          selectedChapterName = allChapters.firstOrNull()?.name ?: ""
          showScheduleDialog = true
        },
        containerColor = AccentPrimaryLight,
        contentColor = Color.Black,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.testTag("schedule_revision_fab")
      ) {
        Icon(Icons.Filled.Add, contentDescription = "Schedule Revision")
      }
    },
    containerColor = DarkBg
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 12.dp)
    ) {
      if (allRevisions.isEmpty()) {
        EmptyStateView(
          title = "No revisions scheduled",
          subtitle = "Schedule chapters for spaced repetition to move knowledge from short-term to permanent memory.",
          icon = Icons.Filled.Repeat,
          actionButtonText = "Schedule a Revision",
          onActionClick = {
            selectedSubjectName = allSubjects.firstOrNull()?.name ?: ""
            selectedChapterName = allChapters.firstOrNull()?.name ?: ""
            showScheduleDialog = true
          },
          modifier = Modifier.weight(1f)
        )
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(top = 10.dp, bottom = 96.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // Overdue Section
          if (overdue.isNotEmpty()) {
            item {
              SectionHeader(title = "Overdue Revisions (${overdue.size})", color = AccentRose)
            }
            items(overdue) { item ->
              RevisionCardItem(
                item = item,
                isOverdue = true,
                onComplete = { completingRevisionItem = item },
                onDelete = { viewModel.deleteRevision(item.id) }
              )
            }
          }

          // Due Today Section
          if (dueToday.isNotEmpty()) {
            item {
              SectionHeader(title = "Due Today (${dueToday.size})", color = AccentAmber)
            }
            items(dueToday) { item ->
              RevisionCardItem(
                item = item,
                isOverdue = false,
                onComplete = { completingRevisionItem = item },
                onDelete = { viewModel.deleteRevision(item.id) }
              )
            }
          }

          // Upcoming Section
          if (upcoming.isNotEmpty()) {
            item {
              SectionHeader(title = "Upcoming (${upcoming.size})", color = AccentBlue)
            }
            items(upcoming) { item ->
              RevisionCardItem(
                item = item,
                isOverdue = false,
                onComplete = { completingRevisionItem = item },
                onDelete = { viewModel.deleteRevision(item.id) }
              )
            }
          }

          // Completed Section
          if (completed.isNotEmpty()) {
            item {
              SectionHeader(title = "Completed (${completed.size})", color = AccentEmerald)
            }
            items(completed) { item ->
              RevisionCardItem(
                item = item,
                isOverdue = false,
                onComplete = {},
                onDelete = { viewModel.deleteRevision(item.id) }
              )
            }
          }
        }
      }
    }
  }

  // Rate & Complete Revision Modal
  completingRevisionItem?.let { item ->
    AlertDialog(
      onDismissRequest = { completingRevisionItem = null },
      containerColor = DarkSurfaceElevated,
      title = {
        Text("How did this revision feel?", fontWeight = FontWeight.Bold, color = TextPrimary)
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = "Rate your recall of '${item.chapterName}'. The app will automatically compute your next spaced repetition interval.",
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = {
                viewModel.completeRevision(item, "DIFFICULT")
                completingRevisionItem = null
              },
              colors = ButtonDefaults.buttonColors(containerColor = AccentRose.copy(alpha = 0.2f)),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f)
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Difficult", color = AccentRose, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("+2 days", color = TextMuted, fontSize = 10.sp)
              }
            }

            Button(
              onClick = {
                viewModel.completeRevision(item, "OKAY")
                completingRevisionItem = null
              },
              colors = ButtonDefaults.buttonColors(containerColor = AccentAmber.copy(alpha = 0.2f)),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f)
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Okay", color = AccentAmber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("+5 days", color = TextMuted, fontSize = 10.sp)
              }
            }

            Button(
              onClick = {
                viewModel.completeRevision(item, "EASY")
                completingRevisionItem = null
              },
              colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald.copy(alpha = 0.2f)),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f)
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Easy", color = AccentEmerald, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("+14 days", color = TextMuted, fontSize = 10.sp)
              }
            }
          }
        }
      },
      confirmButton = {},
      dismissButton = {
        TextButton(onClick = { completingRevisionItem = null }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }

  // Schedule Custom Revision Dialog
  if (showScheduleDialog) {
    AlertDialog(
      onDismissRequest = { showScheduleDialog = false },
      containerColor = DarkSurfaceElevated,
      title = { Text("Schedule Spaced Revision", fontWeight = FontWeight.Bold, color = TextPrimary) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = selectedSubjectName,
            onValueChange = { selectedSubjectName = it },
            label = { Text("Subject") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentBlue,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = selectedChapterName,
            onValueChange = { selectedChapterName = it },
            label = { Text("Chapter / Topic") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentBlue,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          Text("Interval (Spaced Repetition)", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(1, 3, 7, 14, 30).forEach { days ->
              FilterChip(
                selected = selectedIntervalDays == days,
                onClick = { selectedIntervalDays = days },
                label = { Text("${days}d", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = AccentBlue,
                  containerColor = DarkSurfaceVariant
                )
              )
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (selectedChapterName.isNotBlank()) {
              viewModel.scheduleRevision(
                chapterId = 0L,
                chapterName = selectedChapterName.trim(),
                subjectName = selectedSubjectName.trim().ifBlank { "General" },
                daysAhead = selectedIntervalDays
              )
              showScheduleDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
          Text("Schedule", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showScheduleDialog = false }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }
}

@Composable
fun SectionHeader(title: String, color: Color) {
  Text(
    text = title,
    style = MaterialTheme.typography.titleMedium.copy(
      fontWeight = FontWeight.Bold,
      color = color
    ),
    modifier = Modifier.padding(top = 8.dp)
  )
}

@Composable
fun RevisionCardItem(
  item: RevisionItem,
  isOverdue: Boolean,
  onComplete: () -> Unit,
  onDelete: () -> Unit
) {
  val dateStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(item.scheduledDate))

  K001Card(
    backgroundColor = DarkSurface,
    borderColor = if (isOverdue) AccentRose.copy(alpha = 0.5f) else DarkBorder
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = item.chapterName,
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )
        Text(
          text = "${item.subjectName} • Interval: ${item.intervalDays}d",
          style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
          modifier = Modifier.padding(top = 2.dp)
        )
        Text(
          text = if (item.isCompleted) "Completed" else "Scheduled: $dateStr",
          style = MaterialTheme.typography.labelSmall.copy(
            color = if (isOverdue) AccentRose else TextMuted
          ),
          modifier = Modifier.padding(top = 2.dp)
        )
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        if (!item.isCompleted) {
          Button(
            onClick = onComplete,
            colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Text("Review", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }
        } else {
          Icon(
            Icons.Filled.CheckCircle,
            contentDescription = "Completed",
            tint = AccentEmerald,
            modifier = Modifier.size(22.dp)
          )
        }

        IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
          Icon(Icons.Outlined.Delete, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(16.dp))
        }
      }
    }
  }
}
