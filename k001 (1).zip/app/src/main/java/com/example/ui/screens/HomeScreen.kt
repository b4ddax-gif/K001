package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.StudyTask
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@Composable
fun HomeScreen(
  viewModel: K001ViewModel,
  onNavigateToFocus: () -> Unit,
  onNavigateToAiAssistant: () -> Unit,
  onNavigateToNotes: () -> Unit,
  onNavigateToTests: () -> Unit,
  onNavigateToRevision: () -> Unit,
  onNavigateToSubjects: () -> Unit,
  onNavigateToSearch: () -> Unit,
  onNavigateToExams: () -> Unit
) {
  val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
  val allSessions by viewModel.allSessions.collectAsStateWithLifecycle()
  val latestSession by viewModel.latestSession.collectAsStateWithLifecycle()
  val allTasks by viewModel.allTasks.collectAsStateWithLifecycle()
  val allExams by viewModel.allExams.collectAsStateWithLifecycle()
  val quote by viewModel.currentQuote.collectAsStateWithLifecycle()

  // Calculate today's study time
  val todayStr = remember {
    SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
  }
  val todayMinutes = remember(allSessions, todayStr) {
    allSessions.filter { it.dateString == todayStr }.sumOf { it.durationMinutes }
  }

  val dailyGoal = userProfile?.dailyGoalMinutes ?: 120
  val progressFraction = if (dailyGoal > 0) (todayMinutes.toFloat() / dailyGoal) else 0f
  val percentage = (progressFraction.coerceAtMost(1f) * 100).toInt()
  val streak = userProfile?.currentStreak ?: 0

  // Dynamic greeting based on current local hour
  val currentHour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
  val greeting = when (currentHour) {
    in 5..11 -> "Good Morning"
    in 12..16 -> "Good Afternoon"
    in 17..21 -> "Good Evening"
    else -> "Good Night"
  }
  val studentName = userProfile?.studentName?.ifBlank { "Scholar" } ?: "Scholar"

  // Task dialog states
  var showAddTaskDialog by remember { mutableStateOf(false) }
  var taskToEdit by remember { mutableStateOf<StudyTask?>(null) }
  var taskInput by remember { mutableStateOf("") }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(DarkBg)
      .testTag("home_screen"),
    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 88.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // Top Bar / Dynamic Greeting
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "$greeting,",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
          )
          Text(
            text = studentName,
            style = MaterialTheme.typography.headlineMedium.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
        }

        IconButton(
          onClick = onNavigateToSearch,
          modifier = Modifier
            .clip(CircleShape)
            .background(DarkSurfaceElevated)
            .border(1.dp, DarkBorder, CircleShape)
            .testTag("home_search_button")
        ) {
          Icon(
            imageVector = Icons.Filled.Search,
            contentDescription = "Search",
            tint = AccentBlue
          )
        }
      }
    }

    // Today's Progress Card
    item {
      K001Card(modifier = Modifier.testTag("today_progress_card")) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "TODAY'S PROGRESS",
              style = MaterialTheme.typography.labelSmall.copy(
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Bold,
                color = AccentBlue
              )
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "$todayMinutes / $dailyGoal min",
              style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            )
            Text(
              text = "$percentage% completed",
              style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
            )
            Spacer(modifier = Modifier.height(12.dp))
            StreakBadge(streakDays = streak)
          }

          CircularProgressDisplay(
            progress = progressFraction,
            currentValueText = "$todayMinutes",
            goalValueText = "$dailyGoal",
            percentageText = "$percentage%",
            size = 100.dp,
            strokeWidth = 9.dp
          )
        }
      }
    }

    // Continue Studying Card
    item {
      val recentSub = latestSession?.subjectName ?: "Mathematics"
      val recentChap = latestSession?.chapterName ?: "Calculus & Integrals"

      K001Card(
        backgroundColor = DarkSurfaceVariant,
        borderColor = AccentBlue.copy(alpha = 0.3f),
        modifier = Modifier.testTag("continue_studying_card")
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "CONTINUE STUDYING",
              style = MaterialTheme.typography.labelSmall.copy(
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Bold,
                color = AccentEmerald
              )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = recentSub,
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            )
            Text(
              text = recentChap,
              style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }

          Button(
            onClick = {
              onNavigateToFocus()
            },
            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.testTag("continue_study_button")
          ) {
            Icon(
              imageVector = Icons.Filled.PlayArrow,
              contentDescription = null,
              tint = Color.Black,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "Continue",
              style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                color = Color.Black
              )
            )
          }
        }
      }
    }

    // Quick Actions
    item {
      Text(
        text = "Quick Actions",
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
      )
      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        QuickActionItem(
          title = "Start Focus",
          icon = Icons.Filled.Timer,
          iconTint = AccentBlue,
          modifier = Modifier.weight(1f),
          onClick = onNavigateToFocus
        )
        QuickActionItem(
          title = "AI Assistant",
          icon = Icons.Filled.AutoAwesome,
          iconTint = AccentViolet,
          modifier = Modifier.weight(1f),
          onClick = onNavigateToAiAssistant
        )
        QuickActionItem(
          title = "Notes",
          icon = Icons.Filled.EditNote,
          iconTint = AccentEmerald,
          modifier = Modifier.weight(1f),
          onClick = onNavigateToNotes
        )
      }
      Spacer(modifier = Modifier.height(10.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        QuickActionItem(
          title = "Tests",
          icon = Icons.Filled.Quiz,
          iconTint = AccentAmber,
          modifier = Modifier.weight(1f),
          onClick = onNavigateToTests
        )
        QuickActionItem(
          title = "Revision",
          icon = Icons.Filled.Repeat,
          iconTint = AccentPrimaryLight,
          modifier = Modifier.weight(1f),
          onClick = onNavigateToRevision
        )
        QuickActionItem(
          title = "Subjects",
          icon = Icons.Filled.CollectionsBookmark,
          iconTint = AccentRose,
          modifier = Modifier.weight(1f),
          onClick = onNavigateToSubjects
        )
      }
    }

    // Upcoming Exam Widget (if exists)
    if (allExams.isNotEmpty()) {
      val nextExam = allExams.minByOrNull { it.examDateMillis }
      if (nextExam != null) {
        val diffMillis = nextExam.examDateMillis - System.currentTimeMillis()
        val daysRemaining = TimeUnit.MILLISECONDS.toDays(diffMillis).coerceAtLeast(0)

        item {
          K001Card(
            backgroundColor = DarkSurfaceElevated,
            borderColor = AccentAmber.copy(alpha = 0.4f),
            onClick = onNavigateToExams
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(AccentAmber.copy(alpha = 0.15f)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Filled.Event,
                    contentDescription = null,
                    tint = AccentAmber
                  )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                  Text(
                    text = nextExam.name,
                    style = MaterialTheme.typography.titleMedium.copy(
                      fontWeight = FontWeight.Bold,
                      color = TextPrimary
                    )
                  )
                  Text(
                    text = nextExam.subjects,
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                  )
                }
              }

              Text(
                text = "$daysRemaining Days Left",
                style = MaterialTheme.typography.labelLarge.copy(
                  fontWeight = FontWeight.Bold,
                  color = AccentAmber
                )
              )
            }
          }
        }
      }
    }

    // Today's Tasks
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Today's Tasks (${allTasks.count { it.isCompleted }}/${allTasks.size})",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )
        IconButton(
          onClick = {
            taskInput = ""
            showAddTaskDialog = true
          },
          modifier = Modifier.testTag("add_task_button")
        ) {
          Icon(
            imageVector = Icons.Filled.AddCircle,
            contentDescription = "Add Task",
            tint = AccentBlue
          )
        }
      }
    }

    if (allTasks.isEmpty()) {
      item {
        K001Card {
          Text(
            text = "No study tasks scheduled yet. Tap '+' above to add your priority tasks for today.",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
            modifier = Modifier.padding(8.dp)
          )
        }
      }
    } else {
      items(allTasks.size) { index ->
        val task = allTasks[index]
        K001Card(
          backgroundColor = if (task.isCompleted) DarkSurfaceVariant.copy(alpha = 0.5f) else DarkSurface
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Checkbox(
              checked = task.isCompleted,
              onCheckedChange = { viewModel.toggleTask(task) },
              colors = CheckboxDefaults.colors(
                checkedColor = AccentEmerald,
                uncheckedColor = TextMuted,
                checkmarkColor = Color.Black
              ),
              modifier = Modifier.testTag("task_checkbox_$index")
            )
            Text(
              text = task.title,
              style = MaterialTheme.typography.bodyMedium.copy(
                color = if (task.isCompleted) TextMuted else TextPrimary,
                textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None
              ),
              modifier = Modifier
                .weight(1f)
                .padding(horizontal = 4.dp)
            )
            IconButton(
              onClick = {
                taskToEdit = task
                taskInput = task.title
              },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(
                imageVector = Icons.Outlined.Edit,
                contentDescription = "Edit",
                tint = TextSecondary,
                modifier = Modifier.size(16.dp)
              )
            }
            IconButton(
              onClick = { viewModel.deleteTask(task.id) },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(
                imageVector = Icons.Outlined.Delete,
                contentDescription = "Delete",
                tint = AccentRose.copy(alpha = 0.8f),
                modifier = Modifier.size(16.dp)
              )
            }
          }
        }
      }
    }

    // Daily Motivation Quote
    item {
      K001Card(
        backgroundColor = DarkSurfaceElevated,
        borderColor = DarkBorder
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Top
        ) {
          Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.Top
          ) {
            Icon(
              imageVector = Icons.Filled.FormatQuote,
              contentDescription = null,
              tint = AccentBlue,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "DAILY MOTIVATION",
                style = MaterialTheme.typography.labelSmall.copy(
                  color = AccentBlue,
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 1.sp
                )
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "\"$quote\"",
                style = MaterialTheme.typography.bodyMedium.copy(
                  color = TextPrimary,
                  fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
              )
            }
          }

          IconButton(
            onClick = { viewModel.rotateQuote() },
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = Icons.Filled.Refresh,
              contentDescription = "Next Quote",
              tint = TextSecondary,
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }
    }
  }

  // Add Task Dialog
  if (showAddTaskDialog) {
    AlertDialog(
      onDismissRequest = { showAddTaskDialog = false },
      containerColor = DarkSurfaceElevated,
      title = { Text("Add Today's Task", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        OutlinedTextField(
          value = taskInput,
          onValueChange = { taskInput = it },
          placeholder = { Text("e.g. Finish Linear Algebra problem set", color = TextMuted) },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AccentBlue,
            unfocusedBorderColor = DarkBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("task_input_field")
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (taskInput.isNotBlank()) {
              viewModel.addTask(taskInput.trim())
              showAddTaskDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
          Text("Add", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddTaskDialog = false }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }

  // Edit Task Dialog
  taskToEdit?.let { task ->
    AlertDialog(
      onDismissRequest = { taskToEdit = null },
      containerColor = DarkSurfaceElevated,
      title = { Text("Edit Task", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        OutlinedTextField(
          value = taskInput,
          onValueChange = { taskInput = it },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AccentBlue,
            unfocusedBorderColor = DarkBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          modifier = Modifier.fillMaxWidth()
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (taskInput.isNotBlank()) {
              viewModel.updateTask(task, taskInput.trim())
              taskToEdit = null
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
          Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { taskToEdit = null }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }
}

@Composable
fun QuickActionItem(
  title: String,
  icon: ImageVector,
  iconTint: Color,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  Card(
    modifier = modifier
      .clip(RoundedCornerShape(8.dp))
      .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
      .clickable(onClick = onClick)
      .testTag("quick_action_${title.lowercase().replace(" ", "_")}"),
    colors = CardDefaults.cardColors(containerColor = DarkSurface)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 10.dp, horizontal = 4.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Box(
        modifier = Modifier
          .size(30.dp)
          .clip(RoundedCornerShape(6.dp))
          .background(iconTint.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = iconTint,
          modifier = Modifier.size(16.dp)
        )
      }
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.labelSmall.copy(
          fontWeight = FontWeight.SemiBold,
          color = TextPrimary
        ),
        maxLines = 1
      )
    }
  }
}
