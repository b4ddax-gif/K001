package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ai.NoteFormat
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChapterDetailScreen(
  chapterId: Long,
  viewModel: K001ViewModel,
  onBack: () -> Unit,
  onStartFocus: () -> Unit,
  onOpenTest: () -> Unit
) {
  val allChapters by viewModel.allChapters.collectAsStateWithLifecycle()
  val allSubjects by viewModel.allSubjects.collectAsStateWithLifecycle()
  val allNotes by viewModel.allNotes.collectAsStateWithLifecycle()
  val allRevisions by viewModel.allRevisions.collectAsStateWithLifecycle()
  val allTests by viewModel.allTests.collectAsStateWithLifecycle()

  val chapter = allChapters.find { it.id == chapterId }
  val subject = allSubjects.find { it.id == chapter?.subjectId }

  val chapterNotes = remember(allNotes, chapterId) {
    allNotes.filter { it.chapterId == chapterId }
  }
  val chapterRevisions = remember(allRevisions, chapterId) {
    allRevisions.filter { it.chapterId == chapterId }
  }
  val chapterTests = remember(allTests, chapter?.name) {
    allTests.filter { it.chapterName == chapter?.name }
  }

  var showAddNoteDialog by remember { mutableStateOf(false) }
  var noteTitleInput by remember { mutableStateOf("") }
  var noteContentInput by remember { mutableStateOf("") }

  var showScheduleRevisionDialog by remember { mutableStateOf(false) }
  var selectedIntervalDays by remember { mutableIntStateOf(3) }

  var showAiSummaryDialog by remember { mutableStateOf(false) }
  var isGeneratingSummary by remember { mutableStateOf(false) }
  var generatedSummaryText by remember { mutableStateOf<String?>(null) }
  var summaryError by remember { mutableStateOf<String?>(null) }

  var isGeneratingMcqs by remember { mutableStateOf(false) }
  var mcqError by remember { mutableStateOf<String?>(null) }

  val isAiWorking by viewModel.isAiThinking.collectAsStateWithLifecycle()

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = chapter?.name ?: "Chapter Details",
            maxLines = 1,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
      )
    },
    containerColor = DarkBg
  ) { padding ->
    if (chapter == null) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(padding),
        contentAlignment = Alignment.Center
      ) {
        Text("Chapter not found.", color = TextSecondary)
      }
      return@Scaffold
    }

    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp),
      contentPadding = PaddingValues(bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Header Card
      item {
        K001Card(
          backgroundColor = DarkSurface,
          borderColor = DarkBorder
        ) {
          Text(
            text = subject?.name ?: "Subject",
            style = MaterialTheme.typography.labelMedium.copy(
              color = AccentBlue,
              fontWeight = FontWeight.Bold
            )
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = chapter.name,
            style = MaterialTheme.typography.headlineMedium.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            StatusBadge(chapter.status)
            PriorityBadge(chapter.priority)
            Text(
              text = "Total Study: ${chapter.totalStudyMinutes} min",
              style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
            )
          }
        }
      }

      // Action Buttons Row
      item {
        Text(
          text = "Actions",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              viewModel.setSelectedSubjectAndChapter(subject, chapter)
              onStartFocus()
            },
            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Filled.Timer, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Study", color = Color.Black, fontWeight = FontWeight.Bold)
          }

          OutlinedButton(
            onClick = { showAddNoteDialog = true },
            shape = RoundedCornerShape(10.dp),
            border = ButtonDefaults.outlinedButtonBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkBorderLight)),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Filled.EditNote, contentDescription = null, tint = AccentEmerald, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Add Note", color = TextPrimary)
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = { showScheduleRevisionDialog = true },
            shape = RoundedCornerShape(10.dp),
            border = ButtonDefaults.outlinedButtonBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkBorderLight)),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Filled.Repeat, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Revision", color = TextPrimary, fontSize = 12.sp)
          }

          Button(
            onClick = {
              showAiSummaryDialog = true
              isGeneratingSummary = true
              summaryError = null
              generatedSummaryText = null
              viewModel.generateAiNotes(
                content = "Subject: ${subject?.name}, Chapter: ${chapter.name}",
                format = NoteFormat.SUMMARIZE
              )
            },
            colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
            shape = RoundedCornerShape(10.dp),
            border = ButtonDefaults.outlinedButtonBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AccentViolet.copy(alpha = 0.5f))),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = AccentViolet, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("AI Summary", color = TextPrimary, fontSize = 12.sp)
          }

          Button(
            onClick = {
              isGeneratingMcqs = true
              mcqError = null
              viewModel.startAiTest(
                subject = subject?.name ?: "General",
                chapter = chapter.name,
                count = 5,
                difficulty = chapter.priority
              ) {
                isGeneratingMcqs = false
                onOpenTest()
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
            shape = RoundedCornerShape(10.dp),
            border = ButtonDefaults.outlinedButtonBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AccentPrimaryLight.copy(alpha = 0.5f))),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Filled.Quiz, contentDescription = null, tint = AccentPrimaryLight, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("MCQs", color = TextPrimary, fontSize = 12.sp)
          }
        }
      }

      // Revision Schedules
      item {
        Text(
          text = "Revision Schedule",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )
      }

      if (chapterRevisions.isEmpty()) {
        item {
          K001Card {
            Text(
              text = "No revisions scheduled for this chapter. Tap 'Revision' above to schedule spaced repetition.",
              style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
            )
          }
        }
      } else {
        items(chapterRevisions) { rev ->
          val dateStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(rev.scheduledDate))
          K001Card(backgroundColor = DarkSurfaceVariant) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = if (rev.isCompleted) "Completed Revision" else "Due on $dateStr",
                  style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = if (rev.isCompleted) AccentEmerald else TextPrimary
                  )
                )
                Text(
                  text = "Interval: ${rev.intervalDays} days ${rev.lastRating?.let { "• Rated $it" } ?: ""}",
                  style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                )
              }
              if (!rev.isCompleted) {
                Button(
                  onClick = { viewModel.completeRevision(rev, "EASY") },
                  colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald),
                  shape = RoundedCornerShape(8.dp),
                  contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                  Text("Mark Done", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }

      // Chapter Notes
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Chapter Notes (${chapterNotes.size})",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )
          IconButton(onClick = { showAddNoteDialog = true }) {
            Icon(Icons.Filled.Add, contentDescription = "Add Note", tint = AccentBlue)
          }
        }
      }

      if (chapterNotes.isEmpty()) {
        item {
          K001Card {
            Text(
              text = "No notes created yet for this chapter. Add notes manually or generate with AI.",
              style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
            )
          }
        }
      } else {
        items(chapterNotes) { note ->
          K001Card(backgroundColor = DarkSurfaceVariant) {
            Text(
              text = note.title,
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = note.content,
              style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
              maxLines = 3
            )
          }
        }
      }

      // Test History for this Chapter
      item {
        Text(
          text = "Test History (${chapterTests.size})",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )
      }

      if (chapterTests.isEmpty()) {
        item {
          K001Card {
            Text(
              text = "No tests taken yet for this chapter. Tap 'MCQs' above to generate an AI practice test.",
              style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
            )
          }
        }
      } else {
        items(chapterTests) { test ->
          K001Card(backgroundColor = DarkSurfaceElevated) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = test.title,
                  style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                  )
                )
                Text(
                  text = "${test.correctCount}/${test.totalQuestions} correct • ${test.timeTakenSeconds}s taken",
                  style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
              }
              Text(
                text = "${test.percentage}%",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = if (test.percentage >= 70) AccentEmerald else AccentRose
                )
              )
            }
          }
        }
      }
    }
  }

  // Add Note Dialog
  if (showAddNoteDialog) {
    AlertDialog(
      onDismissRequest = { showAddNoteDialog = false },
      containerColor = DarkSurfaceElevated,
      title = { Text("New Note for ${chapter?.name}", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = noteTitleInput,
            onValueChange = { noteTitleInput = it },
            label = { Text("Note Title") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentBlue,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = noteContentInput,
            onValueChange = { noteContentInput = it },
            label = { Text("Content / Key Points") },
            minLines = 4,
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentBlue,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (noteTitleInput.isNotBlank() && noteContentInput.isNotBlank()) {
              viewModel.saveNote(
                title = noteTitleInput.trim(),
                content = noteContentInput.trim(),
                subjectId = subject?.id ?: 0L,
                subjectName = subject?.name ?: "",
                chapterId = chapter?.id ?: 0L,
                chapterName = chapter?.name ?: ""
              )
              showAddNoteDialog = false
              noteTitleInput = ""
              noteContentInput = ""
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
          Text("Save Note", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddNoteDialog = false }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }

  // Schedule Revision Dialog
  if (showScheduleRevisionDialog) {
    AlertDialog(
      onDismissRequest = { showScheduleRevisionDialog = false },
      containerColor = DarkSurfaceElevated,
      title = { Text("Schedule Revision", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = "Select when you want to review ${chapter?.name}:",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
          )
          val intervals = listOf(1 to "Tomorrow", 3 to "3 days", 7 to "7 days", 14 to "14 days", 30 to "30 days")
          intervals.forEach { (days, label) ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable { selectedIntervalDays = days }
                .padding(vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              RadioButton(
                selected = selectedIntervalDays == days,
                onClick = { selectedIntervalDays = days },
                colors = RadioButtonDefaults.colors(selectedColor = AccentBlue)
              )
              Text(
                text = "$label (+${days}d)",
                style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary)
              )
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.scheduleRevision(
              chapterId = chapter?.id ?: 0L,
              chapterName = chapter?.name ?: "",
              subjectName = subject?.name ?: "",
              daysAhead = selectedIntervalDays
            )
            showScheduleRevisionDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
          Text("Schedule", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showScheduleRevisionDialog = false }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }

  // AI Summary Dialog
  if (showAiSummaryDialog) {
    val aiNoteResult by viewModel.aiNotesResult.collectAsStateWithLifecycle()
    val aiNoteError by viewModel.notesError.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGeneratingNotes.collectAsStateWithLifecycle()

    AlertDialog(
      onDismissRequest = { showAiSummaryDialog = false },
      containerColor = DarkSurfaceElevated,
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = AccentViolet)
          Spacer(modifier = Modifier.width(8.dp))
          Text("AI Summary", color = TextPrimary, fontWeight = FontWeight.Bold)
        }
      },
      text = {
        Column(modifier = Modifier.fillMaxWidth()) {
          if (isGenerating) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              contentAlignment = Alignment.Center
            ) {
              CircularProgressIndicator(color = AccentViolet)
            }
          } else if (aiNoteError != null) {
            Text(
              text = aiNoteError ?: "Failed to generate summary.",
              color = AccentRose,
              style = MaterialTheme.typography.bodyMedium
            )
          } else if (aiNoteResult != null) {
            Text(
              text = aiNoteResult ?: "",
              color = TextPrimary,
              style = MaterialTheme.typography.bodyMedium
            )
          }
        }
      },
      confirmButton = {
        if (aiNoteResult != null) {
          Button(
            onClick = {
              viewModel.saveNote(
                title = "${chapter?.name} AI Summary",
                content = aiNoteResult ?: "",
                subjectId = subject?.id ?: 0L,
                subjectName = subject?.name ?: "",
                chapterId = chapter?.id ?: 0L,
                chapterName = chapter?.name ?: ""
              )
              showAiSummaryDialog = false
            },
            colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald)
          ) {
            Text("Save to Notes", color = Color.Black, fontWeight = FontWeight.Bold)
          }
        } else {
          TextButton(onClick = { showAiSummaryDialog = false }) {
            Text("Close", color = TextSecondary)
          }
        }
      },
      dismissButton = {
        if (aiNoteResult != null) {
          TextButton(onClick = { showAiSummaryDialog = false }) {
            Text("Dismiss", color = TextSecondary)
          }
        }
      }
    )
  }
}
