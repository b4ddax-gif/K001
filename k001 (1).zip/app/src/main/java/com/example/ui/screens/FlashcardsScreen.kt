package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ai.GeminiService
import com.example.data.model.Flashcard
import com.example.ui.components.EmptyStateView
import com.example.ui.components.K001Card
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FlashcardsScreen(
  viewModel: K001ViewModel,
  onBack: () -> Unit
) {
  val coroutineScope = rememberCoroutineScope()
  val allFlashcards by viewModel.allFlashcards.collectAsStateWithLifecycle()
  val allSubjects by viewModel.allSubjects.collectAsStateWithLifecycle()

  var isReviewMode by remember { mutableStateOf(false) }
  var reviewIndex by remember { mutableIntStateOf(0) }
  var isCardFlipped by remember { mutableStateOf(false) }

  var showAddManualDialog by remember { mutableStateOf(false) }
  var cardFront by remember { mutableStateOf("") }
  var cardBack by remember { mutableStateOf("") }
  var cardSubject by remember { mutableStateOf("") }

  var showAiGenerateDialog by remember { mutableStateOf(false) }
  var aiMaterialInput by remember { mutableStateOf("") }
  var isGeneratingCards by remember { mutableStateOf(false) }
  var aiCardsError by remember { mutableStateOf<String?>(null) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(if (isReviewMode) "Review Deck" else "Flashcard Decks", fontWeight = FontWeight.Bold, color = TextPrimary)
        },
        navigationIcon = {
          IconButton(onClick = {
            if (isReviewMode) {
              isReviewMode = false
              isCardFlipped = false
            } else {
              onBack()
            }
          }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
      )
    },
    containerColor = DarkBg
  ) { padding ->
    if (isReviewMode && allFlashcards.isNotEmpty()) {
      // Interactive Flashcard Review Mode
      val card = allFlashcards[reviewIndex.coerceIn(0, allFlashcards.size - 1)]

      val rotation by animateFloatAsState(
        targetValue = if (isCardFlipped) 180f else 0f,
        animationSpec = tween(400),
        label = "card_flip"
      )

      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(padding)
          .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
      ) {
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = "CARD ${reviewIndex + 1} OF ${allFlashcards.size}",
            style = MaterialTheme.typography.labelMedium.copy(
              color = AccentBlue,
              letterSpacing = 1.sp,
              fontWeight = FontWeight.Bold
            )
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = card.subjectName,
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
          )
        }

        // Flippable 3D Card
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .height(300.dp)
            .graphicsLayer {
              rotationY = rotation
              cameraDistance = 12f * density
            }
            .clickable { isCardFlipped = !isCardFlipped }
            .testTag("flashcard_card"),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isCardFlipped) DarkSurfaceElevated else DarkSurface
          ),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
              if (isCardFlipped) AccentEmerald.copy(alpha = 0.5f) else DarkBorder
            )
          )
        ) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(24.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center
            ) {
              Text(
                text = if (isCardFlipped) "ANSWER" else "QUESTION",
                style = MaterialTheme.typography.labelSmall.copy(
                  color = if (isCardFlipped) AccentEmerald else AccentBlue,
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 1.5.sp
                )
              )
              Spacer(modifier = Modifier.height(16.dp))
              Text(
                text = if (isCardFlipped) card.backText else card.frontText,
                style = MaterialTheme.typography.titleLarge.copy(
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary,
                  textAlign = TextAlign.Center,
                  lineHeight = 28.sp
                ),
                modifier = Modifier.graphicsLayer {
                  if (isCardFlipped) rotationY = 180f
                }
              )
              Spacer(modifier = Modifier.height(16.dp))
              Text(
                text = if (isCardFlipped) "Tap to flip back" else "Tap card to reveal answer",
                style = MaterialTheme.typography.labelSmall.copy(color = TextMuted),
                modifier = Modifier.graphicsLayer {
                  if (isCardFlipped) rotationY = 180f
                }
              )
            }
          }
        }

        // Rating Buttons
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = "Rate your recall:",
            style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary)
          )
          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = {
                viewModel.rateFlashcard(card, "HARD")
                isCardFlipped = false
                if (reviewIndex < allFlashcards.size - 1) reviewIndex += 1 else isReviewMode = false
              },
              colors = ButtonDefaults.buttonColors(containerColor = AccentRose.copy(alpha = 0.2f)),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f)
            ) {
              Text("Hard", color = AccentRose, fontWeight = FontWeight.Bold)
            }

            Button(
              onClick = {
                viewModel.rateFlashcard(card, "MEDIUM")
                isCardFlipped = false
                if (reviewIndex < allFlashcards.size - 1) reviewIndex += 1 else isReviewMode = false
              },
              colors = ButtonDefaults.buttonColors(containerColor = AccentAmber.copy(alpha = 0.2f)),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f)
            ) {
              Text("Medium", color = AccentAmber, fontWeight = FontWeight.Bold)
            }

            Button(
              onClick = {
                viewModel.rateFlashcard(card, "EASY")
                isCardFlipped = false
                if (reviewIndex < allFlashcards.size - 1) reviewIndex += 1 else isReviewMode = false
              },
              colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald.copy(alpha = 0.2f)),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f)
            ) {
              Text("Easy", color = AccentEmerald, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    } else {
      // Decks list & Management view
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(padding)
          .padding(horizontal = 16.dp)
      ) {
        // Actions Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Button(
            onClick = {
              if (allFlashcards.isNotEmpty()) {
                reviewIndex = 0
                isCardFlipped = false
                isReviewMode = true
              }
            },
            enabled = allFlashcards.isNotEmpty(),
            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.Black)
            Spacer(modifier = Modifier.width(4.dp))
            Text("Review All (${allFlashcards.size})", color = Color.Black, fontWeight = FontWeight.Bold)
          }

          OutlinedButton(
            onClick = {
              aiMaterialInput = ""
              aiCardsError = null
              showAiGenerateDialog = true
            },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.outlinedButtonColors(containerColor = DarkSurfaceElevated),
            border = ButtonDefaults.outlinedButtonBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AccentViolet.copy(alpha = 0.6f))),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = AccentViolet, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("AI Generator", color = AccentViolet, fontWeight = FontWeight.Bold)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Flashcard Cards (${allFlashcards.size})",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          )

          IconButton(onClick = {
            cardFront = ""
            cardBack = ""
            cardSubject = allSubjects.firstOrNull()?.name ?: "General"
            showAddManualDialog = true
          }) {
            Icon(Icons.Filled.Add, contentDescription = "Add Card", tint = AccentBlue)
          }
        }

        if (allFlashcards.isEmpty()) {
          EmptyStateView(
            title = "Deck is empty",
            subtitle = "Add concept flashcards manually or paste study notes to generate cards with AI.",
            icon = Icons.Filled.Style,
            actionButtonText = "Create Flashcard",
            onActionClick = {
              cardFront = ""
              cardBack = ""
              cardSubject = allSubjects.firstOrNull()?.name ?: "General"
              showAddManualDialog = true
            },
            modifier = Modifier.weight(1f)
          )
        } else {
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            items(allFlashcards, key = { it.id }) { card ->
              K001Card(backgroundColor = DarkSurface) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = card.frontText,
                      style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                      )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                      text = card.backText,
                      style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                      horizontalArrangement = Arrangement.spacedBy(8.dp),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text(card.subjectName, style = MaterialTheme.typography.labelSmall.copy(color = AccentBlue))
                      Text("• Reviewed ${card.reviewCount} times", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                    }
                  }

                  IconButton(onClick = { viewModel.deleteFlashcard(card.id) }) {
                    Icon(Icons.Outlined.Delete, contentDescription = "Delete", tint = AccentRose.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  // Add Manual Card Dialog
  if (showAddManualDialog) {
    AlertDialog(
      onDismissRequest = { showAddManualDialog = false },
      containerColor = DarkSurfaceElevated,
      title = { Text("New Flashcard", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = cardSubject,
            onValueChange = { cardSubject = it },
            label = { Text("Subject") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentBlue,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = cardFront,
            onValueChange = { cardFront = it },
            label = { Text("Front (Concept / Question)") },
            minLines = 2,
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentBlue,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = cardBack,
            onValueChange = { cardBack = it },
            label = { Text("Back (Definition / Answer)") },
            minLines = 3,
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentBlue,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (cardFront.isNotBlank() && cardBack.isNotBlank()) {
              viewModel.addFlashcard(
                subject = cardSubject.trim().ifBlank { "General" },
                chapter = "",
                front = cardFront.trim(),
                back = cardBack.trim()
              )
              showAddManualDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
          Text("Add Card", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddManualDialog = false }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }

  // AI Flashcards Generator Dialog
  if (showAiGenerateDialog) {
    AlertDialog(
      onDismissRequest = { if (!isGeneratingCards) showAiGenerateDialog = false },
      containerColor = DarkSurfaceElevated,
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = AccentViolet)
          Spacer(modifier = Modifier.width(8.dp))
          Text("AI Flashcard Deck", color = TextPrimary, fontWeight = FontWeight.Bold)
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = "Paste text, chapter notes, or definitions and Gemini will convert key concepts into flashcards.",
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
          )

          OutlinedTextField(
            value = aiMaterialInput,
            onValueChange = { aiMaterialInput = it },
            placeholder = { Text("Paste study material here...", color = TextMuted) },
            minLines = 5,
            maxLines = 8,
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentViolet,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          if (isGeneratingCards) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(top = 4.dp)
            ) {
              CircularProgressIndicator(modifier = Modifier.size(18.dp), color = AccentViolet, strokeWidth = 2.dp)
              Spacer(modifier = Modifier.width(8.dp))
              Text("Extracting flashcards...", color = AccentViolet, fontSize = 12.sp)
            }
          }

          aiCardsError?.let { err ->
            Text(text = err, color = AccentRose, fontSize = 12.sp)
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (aiMaterialInput.isNotBlank() && !isGeneratingCards) {
              isGeneratingCards = true
              aiCardsError = null
              coroutineScope.launch {
                val result = GeminiService.generateFlashcards(aiMaterialInput.trim())
                isGeneratingCards = false
                if (result.isSuccess) {
                  val cards = result.getOrNull() ?: emptyList()
                  cards.forEach { c ->
                    viewModel.addFlashcard("AI Generated", "", c.front, c.back)
                  }
                  showAiGenerateDialog = false
                } else {
                  aiCardsError = result.exceptionOrNull()?.message ?: "Failed to generate cards."
                }
              }
            }
          },
          enabled = !isGeneratingCards,
          colors = ButtonDefaults.buttonColors(containerColor = AccentViolet)
        ) {
          Text("Generate Cards", color = Color.White, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showAiGenerateDialog = false }, enabled = !isGeneratingCards) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }
}
