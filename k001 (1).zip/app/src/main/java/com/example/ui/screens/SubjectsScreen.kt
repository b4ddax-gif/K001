package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Chapter
import com.example.data.model.Subject
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel

@Composable
fun SubjectsScreen(
  viewModel: K001ViewModel,
  onNavigateToChapter: (Long) -> Unit
) {
  val allSubjects by viewModel.allSubjects.collectAsStateWithLifecycle()
  val allChapters by viewModel.allChapters.collectAsStateWithLifecycle()

  var showAddSubjectDialog by remember { mutableStateOf(false) }
  var subjectNameToAdd by remember { mutableStateOf("") }
  var subjectToEdit by remember { mutableStateOf<Subject?>(null) }
  var editSubjectName by remember { mutableStateOf("") }

  var showAddChapterDialogForSubject by remember { mutableStateOf<Subject?>(null) }
  var chapterNameToAdd by remember { mutableStateOf("") }
  var chapterPriorityToAdd by remember { mutableStateOf("MEDIUM") }

  var chapterToEdit by remember { mutableStateOf<Chapter?>(null) }
  var editChapterName by remember { mutableStateOf("") }
  var editChapterPriority by remember { mutableStateOf("MEDIUM") }

  val expandedSubjectIds = remember { mutableStateMapOf<Long, Boolean>() }

  Scaffold(
    containerColor = DarkBg,
    floatingActionButton = {
      FloatingActionButton(
        onClick = {
          subjectNameToAdd = ""
          showAddSubjectDialog = true
        },
        containerColor = AccentBlue,
        contentColor = Color.Black,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.testTag("add_subject_fab")
      ) {
        Icon(Icons.Filled.Add, contentDescription = "Add Subject")
      }
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 12.dp)
    ) {
      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = "Curriculum & Subjects",
        style = MaterialTheme.typography.headlineMedium.copy(
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
      )
      Text(
        text = "Track your chapters, mastery levels, and study time.",
        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
        modifier = Modifier.padding(top = 2.dp, bottom = 16.dp)
      )

      if (allSubjects.isEmpty()) {
        EmptyStateView(
          title = "No subjects yet",
          subtitle = "Add your first subject to organize your chapters and track mastery.",
          icon = Icons.Filled.MenuBook,
          actionButtonText = "Add Subject",
          onActionClick = { showAddSubjectDialog = true },
          modifier = Modifier.weight(1f)
        )
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(bottom = 96.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(allSubjects, key = { it.id }) { subject ->
            val chaptersForSub = allChapters.filter { it.subjectId == subject.id }
            val totalChaps = chaptersForSub.size
            val completedChaps = chaptersForSub.count { it.status == "COMPLETED" }
            val progressPercent = if (totalChaps > 0) (completedChaps * 100) / totalChaps else 0
            val totalMinutes = chaptersForSub.sumOf { it.totalStudyMinutes }
            val isExpanded = expandedSubjectIds[subject.id] ?: true

            K001Card(
              backgroundColor = DarkSurface,
              borderColor = DarkBorder
            ) {
              // Subject Header Row
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable {
                    expandedSubjectIds[subject.id] = !isExpanded
                  },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                  Box(
                    modifier = Modifier
                      .size(12.dp)
                      .clip(CircleShape)
                      .background(AccentBlue)
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(
                      text = subject.name,
                      style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                      )
                    )
                    Text(
                      text = "$completedChaps/$totalChaps chapters completed • ${totalMinutes}m studied",
                      style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                  }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                  IconButton(
                    onClick = {
                      subjectToEdit = subject
                      editSubjectName = subject.name
                    },
                    modifier = Modifier.size(32.dp)
                  ) {
                    Icon(
                      Icons.Outlined.Edit,
                      contentDescription = "Rename Subject",
                      tint = TextSecondary,
                      modifier = Modifier.size(16.dp)
                    )
                  }
                  IconButton(
                    onClick = { viewModel.deleteSubject(subject.id) },
                    modifier = Modifier.size(32.dp)
                  ) {
                    Icon(
                      Icons.Outlined.Delete,
                      contentDescription = "Delete Subject",
                      tint = AccentRose.copy(alpha = 0.8f),
                      modifier = Modifier.size(16.dp)
                    )
                  }
                  Icon(
                    imageVector = if (isExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(22.dp)
                  )
                }
              }

              // Progress Bar
              Spacer(modifier = Modifier.height(10.dp))
              LinearProgressIndicator(
                progress = { if (totalChaps > 0) completedChaps.toFloat() / totalChaps else 0f },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(6.dp)
                  .clip(RoundedCornerShape(3.dp)),
                color = AccentEmerald,
                trackColor = ProgressTrack
              )

              // Expanded chapters list
              AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                  Divider(color = DarkBorder, thickness = 0.8.dp)
                  Spacer(modifier = Modifier.height(8.dp))

                  if (chaptersForSub.isEmpty()) {
                    Text(
                      text = "No chapters yet in this subject.",
                      style = MaterialTheme.typography.bodySmall.copy(color = TextMuted),
                      modifier = Modifier.padding(vertical = 8.dp)
                    )
                  } else {
                    chaptersForSub.forEach { chapter ->
                      ChapterRowItem(
                        chapter = chapter,
                        onOpen = { onNavigateToChapter(chapter.id) },
                        onToggleComplete = { viewModel.toggleChapterComplete(chapter) },
                        onEdit = {
                          chapterToEdit = chapter
                          editChapterName = chapter.name
                          editChapterPriority = chapter.priority
                        },
                        onDelete = { viewModel.deleteChapter(chapter.id) }
                      )
                    }
                  }

                  // Add Chapter Button for this Subject
                  Button(
                    onClick = {
                      showAddChapterDialogForSubject = subject
                      chapterNameToAdd = ""
                      chapterPriorityToAdd = "MEDIUM"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                    shape = RoundedCornerShape(10.dp),
                    border = ButtonDefaults.outlinedButtonBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkBorder)),
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(top = 8.dp)
                  ) {
                    Icon(
                      Icons.Filled.Add,
                      contentDescription = null,
                      tint = AccentBlue,
                      modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "Add Chapter",
                      style = MaterialTheme.typography.labelMedium.copy(color = AccentBlue)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  // Add Subject Dialog
  if (showAddSubjectDialog) {
    AlertDialog(
      onDismissRequest = { showAddSubjectDialog = false },
      containerColor = DarkSurfaceElevated,
      title = { Text("Add Subject", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        OutlinedTextField(
          value = subjectNameToAdd,
          onValueChange = { subjectNameToAdd = it },
          label = { Text("Subject Name") },
          placeholder = { Text("e.g. Organic Chemistry", color = TextMuted) },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AccentBlue,
            unfocusedBorderColor = DarkBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("subject_name_input")
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (subjectNameToAdd.isNotBlank()) {
              viewModel.addSubject(subjectNameToAdd.trim())
              showAddSubjectDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
          Text("Add", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddSubjectDialog = false }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }

  // Edit Subject Dialog
  subjectToEdit?.let { subject ->
    AlertDialog(
      onDismissRequest = { subjectToEdit = null },
      containerColor = DarkSurfaceElevated,
      title = { Text("Rename Subject", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        OutlinedTextField(
          value = editSubjectName,
          onValueChange = { editSubjectName = it },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AccentBlue,
            unfocusedBorderColor = DarkBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          modifier = Modifier.fillMaxWidth()
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (editSubjectName.isNotBlank()) {
              viewModel.renameSubject(subject, editSubjectName.trim())
              subjectToEdit = null
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
          Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { subjectToEdit = null }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }

  // Add Chapter Dialog
  showAddChapterDialogForSubject?.let { sub ->
    AlertDialog(
      onDismissRequest = { showAddChapterDialogForSubject = null },
      containerColor = DarkSurfaceElevated,
      title = { Text("Add Chapter to ${sub.name}", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          OutlinedTextField(
            value = chapterNameToAdd,
            onValueChange = { chapterNameToAdd = it },
            label = { Text("Chapter / Topic Name") },
            placeholder = { Text("e.g. Thermodynamics", color = TextMuted) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentBlue,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          Text("Priority", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("LOW", "MEDIUM", "HIGH").forEach { p ->
              FilterChip(
                selected = chapterPriorityToAdd == p,
                onClick = { chapterPriorityToAdd = p },
                label = { Text(p, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = AccentBlue,
                  containerColor = DarkSurfaceVariant
                )
              )
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (chapterNameToAdd.isNotBlank()) {
              viewModel.addChapter(sub.id, chapterNameToAdd.trim(), chapterPriorityToAdd)
              showAddChapterDialogForSubject = null
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
          Text("Add", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddChapterDialogForSubject = null }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }

  // Edit Chapter Dialog
  chapterToEdit?.let { chap ->
    AlertDialog(
      onDismissRequest = { chapterToEdit = null },
      containerColor = DarkSurfaceElevated,
      title = { Text("Edit Chapter", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          OutlinedTextField(
            value = editChapterName,
            onValueChange = { editChapterName = it },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AccentBlue,
              unfocusedBorderColor = DarkBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          Text("Priority", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("LOW", "MEDIUM", "HIGH").forEach { p ->
              FilterChip(
                selected = editChapterPriority == p,
                onClick = { editChapterPriority = p },
                label = { Text(p, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = AccentBlue,
                  containerColor = DarkSurfaceVariant
                )
              )
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (editChapterName.isNotBlank()) {
              viewModel.updateChapter(
                chap.copy(name = editChapterName.trim(), priority = editChapterPriority)
              )
              chapterToEdit = null
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
          Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { chapterToEdit = null }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }
}

@Composable
fun ChapterRowItem(
  chapter: Chapter,
  onOpen: () -> Unit,
  onToggleComplete: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .clickable(onClick = onOpen)
      .padding(vertical = 8.dp, horizontal = 4.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    IconButton(
      onClick = onToggleComplete,
      modifier = Modifier.size(28.dp)
    ) {
      Icon(
        imageVector = if (chapter.status == "COMPLETED") Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
        contentDescription = "Status",
        tint = if (chapter.status == "COMPLETED") AccentEmerald else TextMuted,
        modifier = Modifier.size(20.dp)
      )
    }

    Spacer(modifier = Modifier.width(6.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = chapter.name,
        style = MaterialTheme.typography.bodyMedium.copy(
          fontWeight = FontWeight.Medium,
          color = TextPrimary
        )
      )
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.padding(top = 2.dp)
      ) {
        StatusBadge(chapter.status)
        PriorityBadge(chapter.priority)
        Text(
          text = "${chapter.totalStudyMinutes}m studied",
          style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
        )
      }
    }

    IconButton(onClick = onEdit, modifier = Modifier.size(28.dp)) {
      Icon(
        imageVector = Icons.Outlined.Edit,
        contentDescription = "Edit Chapter",
        tint = TextSecondary,
        modifier = Modifier.size(15.dp)
      )
    }

    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
      Icon(
        imageVector = Icons.Outlined.Delete,
        contentDescription = "Delete Chapter",
        tint = AccentRose.copy(alpha = 0.7f),
        modifier = Modifier.size(15.dp)
      )
    }
  }
}
