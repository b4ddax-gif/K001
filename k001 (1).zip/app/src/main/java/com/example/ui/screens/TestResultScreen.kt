package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.K001Card
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestResultScreen(
  testId: Long,
  viewModel: K001ViewModel,
  onBack: () -> Unit
) {
  val allTests by viewModel.allTests.collectAsStateWithLifecycle()
  val test = allTests.find { it.id == testId }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text("Assessment Results", fontWeight = FontWeight.Bold, color = TextPrimary)
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
      )
    },
    containerColor = DarkBg
  ) { padding ->
    if (test == null) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(padding),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("Test result not found.", color = TextSecondary)
          Spacer(modifier = Modifier.height(16.dp))
          Button(onClick = onBack) { Text("Back to Tests") }
        }
      }
      return@Scaffold
    }

    val isPassed = test.percentage >= 60

    // Parse questions JSON and answers JSON
    val questions = remember(test.questionsJson) {
      val list = mutableListOf<ReviewQuestion>()
      try {
        val array = JSONArray(test.questionsJson)
        for (i in 0 until array.length()) {
          val obj = array.getJSONObject(i)
          val q = obj.getString("question")
          val opts = mutableListOf<String>()
          val oArray = obj.getJSONArray("options")
          for (j in 0 until oArray.length()) opts.add(oArray.getString(j))
          val correct = obj.getInt("correctOptionIndex")
          val exp = obj.optString("explanation", "")
          list.add(ReviewQuestion(q, opts, correct, exp))
        }
      } catch (e: Exception) {
        // Fallback
      }
      list
    }

    val userAnswers = remember(test.userAnswersJson) {
      val map = mutableMapOf<Int, Int>()
      try {
        val array = JSONArray(test.userAnswersJson)
        for (i in 0 until array.length()) {
          val obj = array.getJSONObject(i)
          map[obj.getInt("index")] = obj.getInt("selected")
        }
      } catch (e: Exception) {
        // Fallback
      }
      map
    }

    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp),
      contentPadding = PaddingValues(top = 12.dp, bottom = 48.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Score Summary Hero Card
      item {
        K001Card(
          backgroundColor = DarkSurface,
          borderColor = if (isPassed) AccentEmerald.copy(alpha = 0.4f) else AccentRose.copy(alpha = 0.4f)
        ) {
          Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = if (isPassed) "CONGRATULATIONS!" else "KEEP PRACTICING!",
              style = MaterialTheme.typography.labelMedium.copy(
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Bold,
                color = if (isPassed) AccentEmerald else AccentRose
              )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = "${test.percentage}%",
              style = MaterialTheme.typography.displayMedium.copy(
                fontWeight = FontWeight.Black,
                color = TextPrimary
              )
            )

            Text(
              text = "${test.score} out of ${test.totalQuestions} Questions Correct",
              style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
              modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Stats breakdown
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceEvenly
            ) {
              ResultStatItem(label = "Correct", count = test.correctCount, color = AccentEmerald)
              ResultStatItem(label = "Wrong", count = test.wrongCount, color = AccentRose)
              ResultStatItem(label = "Skipped", count = test.skippedCount, color = TextMuted)
              ResultStatItem(label = "Time", countText = "${test.timeTakenSeconds}s", color = AccentAmber)
            }
          }
        }
      }

      // Review Section Header
      item {
        Text(
          text = "Question-by-Question Review",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        )
      }

      // List Questions
      items(questions.size) { index ->
        val q = questions[index]
        val userChoice = userAnswers[index] ?: -1
        val isCorrect = userChoice == q.correctOptionIndex

        K001Card(
          backgroundColor = DarkSurfaceVariant,
          borderColor = if (isCorrect) AccentEmerald.copy(alpha = 0.25f) else AccentRose.copy(alpha = 0.25f)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Question ${index + 1}",
              style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                color = TextSecondary
              )
            )

            if (userChoice == -1) {
              Text("Skipped", color = TextMuted, fontSize = 12.sp)
            } else if (isCorrect) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = AccentEmerald, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Correct", color = AccentEmerald, fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
            } else {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Close, contentDescription = null, tint = AccentRose, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Incorrect", color = AccentRose, fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = q.question,
            style = MaterialTheme.typography.bodyMedium.copy(
              fontWeight = FontWeight.SemiBold,
              color = TextPrimary
            )
          )

          Spacer(modifier = Modifier.height(12.dp))

          // Options Review
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            q.options.forEachIndexed { optIndex, optText ->
              val isUserSelected = userChoice == optIndex
              val isAnswerCorrect = optIndex == q.correctOptionIndex

              val optBg = when {
                isAnswerCorrect -> AccentEmerald.copy(alpha = 0.15f)
                isUserSelected && !isAnswerCorrect -> AccentRose.copy(alpha = 0.15f)
                else -> DarkSurfaceElevated
              }

              val optBorder = when {
                isAnswerCorrect -> AccentEmerald.copy(alpha = 0.6f)
                isUserSelected && !isAnswerCorrect -> AccentRose.copy(alpha = 0.6f)
                else -> DarkBorder
              }

              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .border(1.dp, optBorder, RoundedCornerShape(8.dp))
                  .background(optBg)
                  .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                val letter = ('A'.code + optIndex).toChar()
                Text(
                  text = "$letter.",
                  fontWeight = FontWeight.Bold,
                  color = if (isAnswerCorrect) AccentEmerald else TextPrimary,
                  fontSize = 12.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = optText,
                  style = MaterialTheme.typography.bodySmall.copy(
                    color = if (isAnswerCorrect) AccentEmerald else TextPrimary
                  ),
                  modifier = Modifier.weight(1f)
                )
                if (isAnswerCorrect) {
                  Icon(Icons.Filled.Check, contentDescription = "Correct Answer", tint = AccentEmerald, modifier = Modifier.size(16.dp))
                }
              }
            }
          }

          if (q.explanation.isNotBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(DarkSurfaceElevated)
                .padding(10.dp)
            ) {
              Text(
                text = "Explanation: ${q.explanation}",
                style = MaterialTheme.typography.bodySmall.copy(
                  color = TextSecondary,
                  lineHeight = 18.sp
                )
              )
            }
          }
        }
      }

      // Back to Tests CTA
      item {
        Button(
          onClick = onBack,
          colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
        ) {
          Text("Done Reviewing", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

data class ReviewQuestion(
  val question: String,
  val options: List<String>,
  val correctOptionIndex: Int,
  val explanation: String
)

@Composable
fun ResultStatItem(label: String, count: Int = 0, countText: String? = null, color: Color) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(
      text = countText ?: count.toString(),
      style = MaterialTheme.typography.titleMedium.copy(
        fontWeight = FontWeight.Bold,
        color = color
      )
    )
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
    )
  }
}
