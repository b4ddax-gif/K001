package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.notification.NotificationHelper
import com.example.ui.navigation.BottomNavItems
import com.example.ui.navigation.Screen
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.K001ViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: K001ViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    NotificationHelper.createNotificationChannel(this)

    setContent {
      MyApplicationTheme {
        K001App(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun K001App(viewModel: K001ViewModel) {
  val navController = rememberNavController()
  val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()

  // Wait until profile loaded from local database
  if (userProfile == null) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(DarkBg),
      contentAlignment = Alignment.Center
    ) {
      CircularProgressIndicator(color = AccentBlue)
    }
    return
  }

  val isOnboarded = userProfile?.isOnboarded == true
  val startDestination = if (isOnboarded) Screen.Home.route else Screen.Onboarding.route

  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route

  val isBottomBarVisible = currentRoute in BottomNavItems.map { it.route }

  Scaffold(
    containerColor = DarkBg,
    bottomBar = {
      if (isBottomBarVisible) {
        NavigationBar(
          containerColor = DarkSurface,
          tonalElevation = 0.dp,
          modifier = Modifier
            .border(width = 0.8.dp, color = DarkBorder)
            .testTag("bottom_nav_bar")
        ) {
          BottomNavItems.forEach { screen ->
            val isSelected = currentRoute == screen.route
            NavigationBarItem(
              selected = isSelected,
              onClick = {
                navController.navigate(screen.route) {
                  popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                  }
                  launchSingleTop = true
                  restoreState = true
                }
              },
              icon = {
                val icon = if (isSelected) screen.selectedIcon else screen.unselectedIcon
                if (icon != null) {
                  Icon(
                    imageVector = icon,
                    contentDescription = screen.title
                  )
                }
              },
              label = {
                Text(
                  text = screen.title,
                  style = MaterialTheme.typography.labelSmall
                )
              },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AccentBlue,
                selectedTextColor = AccentBlue,
                unselectedIconColor = TextSecondary,
                unselectedTextColor = TextSecondary,
                indicatorColor = DarkSurfaceElevated
              ),
              modifier = Modifier.testTag("nav_item_${screen.title.lowercase()}")
            )
          }
        }
      }
    }
  ) { innerPadding ->
    NavHost(
      navController = navController,
      startDestination = startDestination,
      modifier = Modifier.padding(innerPadding)
    ) {
      // 1. Onboarding
      composable(Screen.Onboarding.route) {
        OnboardingScreen(
          viewModel = viewModel,
          onComplete = {
            navController.navigate(Screen.Home.route) {
              popUpTo(Screen.Onboarding.route) { inclusive = true }
            }
          }
        )
      }

      // 2. Home Dashboard
      composable(Screen.Home.route) {
        HomeScreen(
          viewModel = viewModel,
          onNavigateToFocus = { navController.navigate(Screen.Focus.route) },
          onNavigateToAiAssistant = { navController.navigate(Screen.AiAssistant.route) },
          onNavigateToNotes = { navController.navigate(Screen.Notes.route) },
          onNavigateToTests = { navController.navigate(Screen.Tests.route) },
          onNavigateToRevision = { navController.navigate(Screen.Revision.route) },
          onNavigateToSubjects = { navController.navigate(Screen.Subjects.route) },
          onNavigateToSearch = { navController.navigate(Screen.Search.route) },
          onNavigateToExams = { navController.navigate(Screen.Exams.route) }
        )
      }

      // 3. Subjects & Chapters
      composable(Screen.Subjects.route) {
        SubjectsScreen(
          viewModel = viewModel,
          onNavigateToChapter = { chapterId ->
            navController.navigate(Screen.ChapterDetail.createRoute(chapterId))
          }
        )
      }

      // 4. Focus Timer
      composable(Screen.Focus.route) {
        FocusTimerScreen(viewModel = viewModel)
      }

      // 5. Notes
      composable(Screen.Notes.route) {
        NotesScreen(
          viewModel = viewModel,
          onOpenAiNotes = { navController.navigate(Screen.AiNotes.route) }
        )
      }

      // 6. Profile & Settings
      composable(Screen.Profile.route) {
        ProfileScreen(
          viewModel = viewModel,
          onNavigateToAnalytics = { navController.navigate(Screen.Analytics.route) },
          onNavigateToExams = { navController.navigate(Screen.Exams.route) },
          onNavigateToFlashcards = { navController.navigate(Screen.Flashcards.route) }
        )
      }

      // Contextual screens
      composable(
        route = Screen.ChapterDetail.route,
        arguments = listOf(navArgument("chapterId") { type = NavType.LongType })
      ) { backStackEntry ->
        val chapterId = backStackEntry.arguments?.getLong("chapterId") ?: 0L
        ChapterDetailScreen(
          chapterId = chapterId,
          viewModel = viewModel,
          onBack = { navController.popBackStack() },
          onStartFocus = { navController.navigate(Screen.Focus.route) },
          onOpenTest = { navController.navigate(Screen.TakeTest.createRoute("ai")) }
        )
      }

      composable(Screen.AiAssistant.route) {
        AiAssistantScreen(
          viewModel = viewModel,
          onBack = { navController.popBackStack() }
        )
      }

      composable(Screen.AiNotes.route) {
        AiNotesScreen(
          viewModel = viewModel,
          onBack = { navController.popBackStack() }
        )
      }

      composable(Screen.Tests.route) {
        TestsScreen(
          viewModel = viewModel,
          onBack = { navController.popBackStack() },
          onOpenTest = { navController.navigate(Screen.TakeTest.createRoute("ai")) },
          onViewResult = { testId -> navController.navigate(Screen.TestResult.createRoute(testId)) }
        )
      }

      composable(
        route = Screen.TakeTest.route,
        arguments = listOf(navArgument("mode") { type = NavType.StringType })
      ) {
        TakeTestScreen(
          viewModel = viewModel,
          onBack = { navController.popBackStack() },
          onTestSubmitted = { testId ->
            navController.navigate(Screen.TestResult.createRoute(testId)) {
              popUpTo(Screen.Tests.route)
            }
          }
        )
      }

      composable(
        route = Screen.TestResult.route,
        arguments = listOf(navArgument("testId") { type = NavType.LongType })
      ) { backStackEntry ->
        val testId = backStackEntry.arguments?.getLong("testId") ?: 0L
        TestResultScreen(
          testId = testId,
          viewModel = viewModel,
          onBack = { navController.navigate(Screen.Tests.route) { popUpTo(Screen.Home.route) } }
        )
      }

      composable(Screen.Revision.route) {
        RevisionScreen(
          viewModel = viewModel,
          onBack = { navController.popBackStack() }
        )
      }

      composable(Screen.Flashcards.route) {
        FlashcardsScreen(
          viewModel = viewModel,
          onBack = { navController.popBackStack() }
        )
      }

      composable(Screen.Analytics.route) {
        AnalyticsScreen(
          viewModel = viewModel,
          onBack = { navController.popBackStack() }
        )
      }

      composable(Screen.Exams.route) {
        ExamsScreen(
          viewModel = viewModel,
          onBack = { navController.popBackStack() }
        )
      }

      composable(Screen.Search.route) {
        SearchScreen(
          viewModel = viewModel,
          onBack = { navController.popBackStack() },
          onNavigateToChapter = { chapterId -> navController.navigate(Screen.ChapterDetail.createRoute(chapterId)) },
          onNavigateToNotes = { navController.navigate(Screen.Notes.route) },
          onNavigateToSubjects = { navController.navigate(Screen.Subjects.route) }
        )
      }
    }
  }
}
